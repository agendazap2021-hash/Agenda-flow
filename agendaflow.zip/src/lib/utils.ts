import { Appointment, AppointmentColor, AppointmentStatus, ReminderOption, TaskPriority } from '../types';

/**
 * Returns today's date in YYYY-MM-DD format based on local time
 */
export function getTodayString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Format date in Brazilian Portuguese: "23 de Setembro de 2026" or "23/09/2026"
 */
export function formatDateBR(dateStr: string): string {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-').map(Number);
  if (!year || !month || !day) return dateStr;
  const d = new Date(year, month - 1, day);
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

export function formatDateExtended(dateStr: string): string {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-').map(Number);
  if (!year || !month || !day) return dateStr;
  const d = new Date(year, month - 1, day);
  return d.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
}

/**
 * Time string to minutes since midnight: "09:30" -> 570
 */
export function timeToMinutes(timeStr: string): number {
  if (!timeStr) return 0;
  const [h, m] = timeStr.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

/**
 * Minutes to time string: 570 -> "09:30"
 */
export function minutesToTime(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/**
 * Checks if two time intervals overlap on the same date
 */
export function checkAppointmentConflict(
  candidate: { date: string; start_time: string; end_time: string; id?: string },
  existingAppointments: Appointment[]
): Appointment | null {
  const candStart = timeToMinutes(candidate.start_time);
  const candEnd = timeToMinutes(candidate.end_time);

  if (candEnd <= candStart) {
    return null; // Invalid range or handled by form validation
  }

  for (const apt of existingAppointments) {
    // Exclude self when editing
    if (candidate.id && apt.id === candidate.id) continue;
    // Exclude cancelled
    if (apt.status === 'CANCELLED') continue;
    // Must be on the exact same date
    if (apt.date !== candidate.date) continue;

    const aptStart = timeToMinutes(apt.start_time);
    const aptEnd = timeToMinutes(apt.end_time);

    // Overlap condition: start < otherEnd AND end > otherStart
    if (candStart < aptEnd && candEnd > aptStart) {
      return apt;
    }
  }

  return null;
}

/**
 * Generates official WhatsApp message as defined in requirement #14:
 * "Olá, {nome}!
 * 
 * Lembrete do seu compromisso:
 * 
 * 📅 {data}
 * 🕐 {horário}
 * 📌 {título}
 * 
 * Até lá!"
 */
export function generateWhatsAppMessage(apt: Appointment): string {
  const clientName = apt.client_name?.trim() || 'Cliente';
  const formattedDate = formatDateBR(apt.date);
  const timeRange = `${apt.start_time} às ${apt.end_time}`;

  return `Olá, ${clientName}!

Lembrete do seu compromisso:

📅 ${formattedDate}
🕐 ${timeRange}
📌 ${apt.title}

Até lá!`;
}

/**
 * Opens WhatsApp Web/App with prefilled message
 */
export function openWhatsApp(phone: string | undefined, message: string) {
  if (!phone) {
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
    return;
  }
  // Sanitize phone: remove non-digits
  let cleanPhone = phone.replace(/\D/g, '');
  // If Brazilian number without country code (10 or 11 digits), prepend 55
  if (cleanPhone.length === 10 || cleanPhone.length === 11) {
    cleanPhone = '55' + cleanPhone;
  }
  const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
}

/**
 * Color metadata definitions
 */
export const COLOR_MAP: Record<AppointmentColor, {
  name: string;
  badge: string;
  bg: string;
  border: string;
  text: string;
  dot: string;
  hex: string;
}> = {
  blue: {
    name: 'Trabalho',
    badge: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-800',
    bg: 'bg-blue-500',
    border: 'border-blue-500',
    text: 'text-blue-600 dark:text-blue-400',
    dot: 'bg-blue-500',
    hex: '#3b82f6',
  },
  green: {
    name: 'Pessoal',
    badge: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800',
    bg: 'bg-emerald-500',
    border: 'border-emerald-500',
    text: 'text-emerald-600 dark:text-emerald-400',
    dot: 'bg-emerald-500',
    hex: '#10b981',
  },
  yellow: {
    name: 'Reunião',
    badge: 'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800',
    bg: 'bg-amber-500',
    border: 'border-amber-500',
    text: 'text-amber-600 dark:text-amber-400',
    dot: 'bg-amber-500',
    hex: '#f59e0b',
  },
  red: {
    name: 'Urgente',
    badge: 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800',
    bg: 'bg-rose-500',
    border: 'border-rose-500',
    text: 'text-rose-600 dark:text-rose-400',
    dot: 'bg-rose-500',
    hex: '#f43f5e',
  },
  purple: {
    name: 'Atendimento',
    badge: 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/40 dark:text-purple-300 dark:border-purple-800',
    bg: 'bg-purple-500',
    border: 'border-purple-500',
    text: 'text-purple-600 dark:text-purple-400',
    dot: 'bg-purple-500',
    hex: '#a855f7',
  },
  indigo: {
    name: 'Geral',
    badge: 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/40 dark:text-indigo-300 dark:border-indigo-800',
    bg: 'bg-indigo-500',
    border: 'border-indigo-500',
    text: 'text-indigo-600 dark:text-indigo-400',
    dot: 'bg-indigo-500',
    hex: '#6366f1',
  },
  teal: {
    name: 'Consulta',
    badge: 'bg-teal-50 text-teal-700 border-teal-200 dark:bg-teal-950/40 dark:text-teal-300 dark:border-teal-800',
    bg: 'bg-teal-500',
    border: 'border-teal-500',
    text: 'text-teal-600 dark:text-teal-400',
    dot: 'bg-teal-500',
    hex: '#14b8a6',
  },
};

export const STATUS_MAP: Record<AppointmentStatus, {
  label: string;
  badge: string;
  dot: string;
}> = {
  PENDING: {
    label: 'Pendente',
    badge: 'bg-amber-100/70 text-amber-800 border-amber-300 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800',
    dot: 'bg-amber-500',
  },
  CONFIRMED: {
    label: 'Confirmado',
    badge: 'bg-emerald-100/70 text-emerald-800 border-emerald-300 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800',
    dot: 'bg-emerald-500',
  },
  COMPLETED: {
    label: 'Concluído',
    badge: 'bg-blue-100/70 text-blue-800 border-blue-300 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-800',
    dot: 'bg-blue-500',
  },
  CANCELLED: {
    label: 'Cancelado',
    badge: 'bg-slate-100 text-slate-600 border-slate-300 line-through dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700',
    dot: 'bg-slate-400',
  },
};

export const PRIORITY_MAP: Record<TaskPriority, {
  label: string;
  badge: string;
  dot: string;
}> = {
  LOW: {
    label: 'Baixa',
    badge: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
    dot: 'bg-slate-400',
  },
  MEDIUM: {
    label: 'Média',
    badge: 'bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300',
    dot: 'bg-amber-500',
  },
  HIGH: {
    label: 'Alta',
    badge: 'bg-rose-100 text-rose-800 dark:bg-rose-950/50 dark:text-rose-300',
    dot: 'bg-rose-500',
  },
};

export const REMINDER_MAP: Record<ReminderOption, string> = {
  none: 'Sem lembrete',
  '5m': '5 minutos antes',
  '15m': '15 minutos antes',
  '30m': '30 minutos antes',
  '1h': '1 hora antes',
  '1d': '1 dia antes',
};

/**
 * Formats currency in BRL (R$ 150,00)
 */
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(amount);
}
