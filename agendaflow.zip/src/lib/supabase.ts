import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Read from env, localStorage or project defaults
const STORAGE_KEY_URL = 'agendaflow_supabase_url';
const STORAGE_KEY_KEY = 'agendaflow_supabase_anon_key';

// Configuração padrão fornecida pelo usuário
const DEFAULT_SUPABASE_URL = 'https://qkgrkhogbtqaaonuppze.supabase.co';
const DEFAULT_SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFrZ3JraG9nYnRxYWFvbnVwcHplIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTAxNzc3NTUsImV4cCI6MjEwNTc1Mzc1NX0.lf7eohfHIqZjGx9JDzn4oGip73m28O7xfN-rB69x9H4';

export function getSupabaseCredentials(): { url: string; anonKey: string } {
  const customUrl = localStorage.getItem(STORAGE_KEY_URL);
  const customKey = localStorage.getItem(STORAGE_KEY_KEY);

  const url = customUrl || (import.meta.env.VITE_SUPABASE_URL as string) || DEFAULT_SUPABASE_URL;
  const anonKey = customKey || (import.meta.env.VITE_SUPABASE_ANON_KEY as string) || DEFAULT_SUPABASE_ANON_KEY;

  return { url, anonKey };
}

export function saveSupabaseCredentials(url: string, anonKey: string) {
  if (url && anonKey) {
    localStorage.setItem(STORAGE_KEY_URL, url.trim());
    localStorage.setItem(STORAGE_KEY_KEY, anonKey.trim());
  } else {
    localStorage.removeItem(STORAGE_KEY_URL);
    localStorage.removeItem(STORAGE_KEY_KEY);
  }
}

let supabaseInstance: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient | null {
  const { url, anonKey } = getSupabaseCredentials();

  if (!url || !anonKey || !url.startsWith('http')) {
    return null;
  }

  if (!supabaseInstance) {
    try {
      supabaseInstance = createClient(url, anonKey, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
        },
      });
    } catch (e) {
      console.error('Failed to initialize Supabase client:', e);
      return null;
    }
  }

  return supabaseInstance;
}

export function resetSupabaseClient() {
  supabaseInstance = null;
}

/**
 * Complete SQL Migration Script for Supabase with Row Level Security (RLS)
 */
export const SUPABASE_SQL_SCHEMA = `-- ========================================================
-- AgendaFlow - Banco de Dados Supabase com Row Level Security
-- ========================================================

-- 1. Tabela: settings (Configurações do Usuário)
CREATE TABLE IF NOT EXISTS public.settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL DEFAULT '',
  profile_photo TEXT,
  phone TEXT,
  email TEXT NOT NULL,
  theme TEXT NOT NULL DEFAULT 'system',
  start_hour TEXT NOT NULL DEFAULT '08:00',
  end_hour TEXT NOT NULL DEFAULT '19:00',
  default_calendar_view TEXT NOT NULL DEFAULT 'week',
  first_day_of_week TEXT NOT NULL DEFAULT 'monday',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT settings_user_id_key UNIQUE (user_id)
);

-- 2. Tabela: services (Serviços Oferecidos)
CREATE TABLE IF NOT EXISTS public.services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  duration INTEGER NOT NULL DEFAULT 30, -- minutos
  price NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Tabela: clients (Clientes / Contatos)
CREATE TABLE IF NOT EXISTS public.clients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. Tabela: appointments (Compromissos e Agendamentos)
CREATE TABLE IF NOT EXISTS public.appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  date DATE NOT NULL,
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  client_name TEXT,
  client_phone TEXT,
  service_name TEXT,
  location TEXT,
  status TEXT NOT NULL DEFAULT 'CONFIRMED' CHECK (status IN ('PENDING', 'CONFIRMED', 'COMPLETED', 'CANCELLED')),
  color TEXT NOT NULL DEFAULT 'blue',
  reminder TEXT NOT NULL DEFAULT '15m',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. Tabela: tasks (Tarefas)
CREATE TABLE IF NOT EXISTS public.tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  due_date DATE,
  due_time TEXT,
  priority TEXT NOT NULL DEFAULT 'MEDIUM' CHECK (priority IN ('LOW', 'MEDIUM', 'HIGH')),
  completed BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ========================================================
-- HABILITAR ROW LEVEL SECURITY (RLS)
-- Cada usuário visualiza e manipula SOMENTE seus próprios dados
-- ========================================================

ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

-- Políticas para settings
CREATE POLICY "Users can view their own settings"
  ON public.settings FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own settings"
  ON public.settings FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own settings"
  ON public.settings FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own settings"
  ON public.settings FOR DELETE USING (auth.uid() = user_id);

-- Políticas para services
CREATE POLICY "Users can view their own services"
  ON public.services FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own services"
  ON public.services FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own services"
  ON public.services FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own services"
  ON public.services FOR DELETE USING (auth.uid() = user_id);

-- Políticas para clients
CREATE POLICY "Users can view their own clients"
  ON public.clients FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own clients"
  ON public.clients FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own clients"
  ON public.clients FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own clients"
  ON public.clients FOR DELETE USING (auth.uid() = user_id);

-- Políticas para appointments
CREATE POLICY "Users can view their own appointments"
  ON public.appointments FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own appointments"
  ON public.appointments FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own appointments"
  ON public.appointments FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own appointments"
  ON public.appointments FOR DELETE USING (auth.uid() = user_id);

-- Políticas para tasks
CREATE POLICY "Users can view their own tasks"
  ON public.tasks FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own tasks"
  ON public.tasks FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own tasks"
  ON public.tasks FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own tasks"
  ON public.tasks FOR DELETE USING (auth.uid() = user_id);

-- Índices para alta performance de busca
CREATE INDEX IF NOT EXISTS idx_appointments_user_date ON public.appointments (user_id, date);
CREATE INDEX IF NOT EXISTS idx_tasks_user_date ON public.tasks (user_id, due_date);
CREATE INDEX IF NOT EXISTS idx_clients_user_name ON public.clients (user_id, name);
CREATE INDEX IF NOT EXISTS idx_services_user ON public.services (user_id);
`;
