import React, { useState } from 'react';
import { Download, Smartphone, X, Check, Apple, FileCode2 } from 'lucide-react';
import { usePWAInstall } from '../lib/usePWAInstall';

interface InstallAppButtonProps {
  variant?: 'button' | 'compact' | 'sidebar' | 'banner';
  className?: string;
}

export const InstallAppButton: React.FC<InstallAppButtonProps> = ({
  variant = 'button',
  className = '',
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);

  // If already running inside standalone PWA app, we don't need to show install
  if (isInstalled) {
    return null;
  }

  const handleClick = async () => {
    if (isInstallable) {
      const installed = await install();
      if (!installed) {
        setShowModal(true);
      }
    } else {
      setShowModal(true);
    }
  };

  return (
    <>
      {variant === 'sidebar' && (
        <button
          onClick={handleClick}
          type="button"
          className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-medium text-sm transition-all bg-gradient-to-r from-emerald-500/10 to-teal-500/10 hover:from-emerald-500/20 hover:to-teal-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 ${className}`}
        >
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-emerald-500 text-white shadow-xs">
              <Download className="w-3.5 h-3.5" />
            </div>
            <div className="text-left">
              <span className="block text-xs font-bold leading-tight">Baixar App</span>
              <span className="block text-[10px] text-slate-400">Instalar no celular/PC</span>
            </div>
          </div>
          <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
            Grátis
          </span>
        </button>
      )}

      {variant === 'compact' && (
        <button
          onClick={handleClick}
          type="button"
          title="Baixar App no Celular ou Computador"
          className={`flex items-center gap-1.5 px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-transform active:scale-95 ${className}`}
        >
          <Download className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Baixar App</span>
        </button>
      )}

      {variant === 'button' && (
        <button
          onClick={handleClick}
          type="button"
          className={`flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 active:scale-98 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-500/20 transition-all ${className}`}
        >
          <Download className="w-4 h-4 animate-bounce" />
          <span>Baixar App (Instalar)</span>
        </button>
      )}

      {variant === 'banner' && (
        <div className={`p-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${className}`}>
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/20 backdrop-blur-xs rounded-xl text-white">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm">Use como aplicativo no seu celular!</h4>
              <p className="text-xs text-emerald-100 mt-0.5">
                Acesse rápido com um toque na sua tela inicial, sem precisar de loja ou download pesado.
              </p>
            </div>
          </div>
          <button
            onClick={handleClick}
            className="px-4 py-2 bg-white text-emerald-800 hover:bg-emerald-50 active:bg-emerald-100 rounded-xl text-xs font-bold shadow-xs whitespace-nowrap transition-colors self-end sm:self-auto"
          >
            Baixar Agora
          </button>
        </div>
      )}

      {/* Modal Tutorial de Instalação (se o navegador exigir manual) */}
      {showModal && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setShowModal(false)}
        >
          <div 
            className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 text-slate-900 dark:text-white relative animate-in zoom-in-95 duration-200"
            onClick={e => e.stopPropagation()}
          >
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-5 right-5 p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-md shadow-emerald-500/30">
                <Download className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold">Como Baixar o App</h3>
                <p className="text-xs text-slate-400">Instalação direta e instantânea no celular ou PC</p>
              </div>
            </div>

            {/* Se for iPhone / iPad */}
            {isIOS ? (
              <div className="space-y-3.5 py-2">
                <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 text-xs">
                  No <strong>iPhone / iPad</strong>, use o navegador <strong>Safari</strong>:
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold flex-shrink-0">1</span>
                  <p className="text-xs text-slate-700 dark:text-slate-300">
                    Toque no botão de <strong>Compartilhar</strong> (ícone de um quadrado com seta para cima na barra do Safari).
                  </p>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold flex-shrink-0">2</span>
                  <p className="text-xs text-slate-700 dark:text-slate-300">
                    Role as opções para baixo e toque em <strong>"Adicionar à Tela de Início"</strong>.
                  </p>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold flex-shrink-0">3</span>
                  <p className="text-xs text-slate-700 dark:text-slate-300">
                    Toque em <strong>"Adicionar"</strong> no canto superior direito. Pronto! O ícone do AgendaFlow estará na sua tela inicial!
                  </p>
                </div>
              </div>
            ) : (
              /* Android e Chrome / Edge no PC */
              <div className="space-y-3.5 py-2">
                {isInstallable && (
                  <button
                    onClick={async () => {
                      const res = await install();
                      if (res) setShowModal(false);
                    }}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-xl text-sm font-bold shadow-md flex items-center justify-center gap-2 transition-all mb-2"
                  >
                    <Download className="w-4 h-4" />
                    <span>Confirmar e Instalar Agora</span>
                  </button>
                )}

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold flex-shrink-0">1</span>
                  <p className="text-xs text-slate-700 dark:text-slate-300">
                    No <strong>Google Chrome</strong> (Android ou Computador), clique nos <strong>3 pontinhos</strong> no canto superior direito.
                  </p>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold flex-shrink-0">2</span>
                  <p className="text-xs text-slate-700 dark:text-slate-300">
                    Clique em <strong>"Instalar aplicativo"</strong> ou <strong>"Adicionar à tela inicial"</strong>.
                  </p>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold flex-shrink-0">3</span>
                  <p className="text-xs text-slate-700 dark:text-slate-300">
                    Confirme a instalação. O aplicativo abrirá em tela cheia como um app nativo, rápido e sem barra de navegador!
                  </p>
                </div>
              </div>
            )}

            {/* Opção Baixar Arquivo HTML Único */}
            <div className="mt-3 p-3.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-800/60">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-700 dark:text-indigo-300">
                  <FileCode2 className="w-4 h-4" />
                  <span>Baixar Arquivo HTML Offline (.html)</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-200/50 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-300 font-bold">
                  Portátil
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-2.5 leading-relaxed">
                Arquivo HTML único completo. Funciona dando 2 cliques em qualquer computador ou enviando por WhatsApp, sem precisar de servidor.
              </p>
              <a
                href="/agendaflow_completo.html"
                download="agendaflow_completo.html"
                className="w-full py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Baixar agendaflow_completo.html</span>
              </a>
            </div>

            <button
              onClick={() => setShowModal(false)}
              className="mt-4 w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs transition-colors"
            >
              Entendido
            </button>
          </div>
        </div>
      )}
    </>
  );
};
