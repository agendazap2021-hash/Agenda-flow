import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  X, 
  Calendar as CalendarIcon, 
  CheckSquare, 
  User, 
  Briefcase, 
  ArrowRight,
  Clock
} from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { Appointment, Client, Service, Task } from '../types';
import { COLOR_MAP, formatDateBR, STATUS_MAP } from '../lib/utils';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAppointment: (apt: Appointment) => void;
  onSelectTask: (task: Task) => void;
  onSelectClient: (client: Client) => void;
  onSelectService: (service: Service) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectAppointment,
  onSelectTask,
  onSelectClient,
  onSelectService,
}) => {
  const { appointments, tasks, clients, services } = useData();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  // Keyboard shortcut listener for ESC
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const q = query.toLowerCase().trim();

  const filteredAppointments = q ? appointments.filter(a => 
    a.title.toLowerCase().includes(q) ||
    a.description?.toLowerCase().includes(q) ||
    a.client_name?.toLowerCase().includes(q) ||
    a.location?.toLowerCase().includes(q) ||
    a.service_name?.toLowerCase().includes(q)
  ) : [];

  const filteredTasks = q ? tasks.filter(t =>
    t.title.toLowerCase().includes(q) ||
    t.description?.toLowerCase().includes(q)
  ) : [];

  const filteredClients = q ? clients.filter(c =>
    c.name.toLowerCase().includes(q) ||
    c.phone?.toLowerCase().includes(q) ||
    c.email?.toLowerCase().includes(q) ||
    c.notes?.toLowerCase().includes(q)
  ) : [];

  const filteredServices = q ? services.filter(s =>
    s.name.toLowerCase().includes(q) ||
    s.description?.toLowerCase().includes(q)
  ) : [];

  const totalResults = filteredAppointments.length + filteredTasks.length + filteredClients.length + filteredServices.length;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 px-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        role="dialog"
        aria-modal="true"
        className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[80vh]"
      >
        {/* Search Bar Input */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-200 dark:border-slate-800 gap-3">
          <Search className="w-5 h-5 text-indigo-500 flex-shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Pesquisar compromissos, tarefas, clientes ou serviços..."
            className="flex-1 bg-transparent border-none text-base text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 px-2 py-1 rounded-lg"
            >
              Limpar
            </button>
          )}
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1.5 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results Container */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {!q ? (
            <div className="py-12 text-center text-slate-400">
              <Search className="w-10 h-10 mx-auto mb-3 opacity-30" />
              <p className="text-sm font-medium">Digite para pesquisar em toda a sua agenda</p>
              <p className="text-xs text-slate-500 mt-1">
                Busca por nome de cliente, título de reunião, tarefa ou serviço
              </p>
            </div>
          ) : totalResults === 0 ? (
            <div className="py-12 text-center text-slate-400">
              <p className="text-sm font-medium">Nenhum resultado encontrado para "{query}"</p>
              <p className="text-xs text-slate-500 mt-1">Verifique a ortografia ou tente palavras-chave diferentes</p>
            </div>
          ) : (
            <>
              {/* Compromissos */}
              {filteredAppointments.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
                    <CalendarIcon className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Compromissos ({filteredAppointments.length})</span>
                  </div>
                  <div className="space-y-1.5">
                    {filteredAppointments.map(apt => (
                      <div
                        key={apt.id}
                        onClick={() => {
                          onClose();
                          onSelectAppointment(apt);
                        }}
                        className="p-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/80 cursor-pointer transition-colors flex items-center justify-between group border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-2.5 h-8 rounded-full ${COLOR_MAP[apt.color].bg}`} />
                          <div>
                            <div className="text-sm font-semibold text-slate-900 dark:text-white group-hover:text-indigo-600 transition-colors">
                              {apt.title}
                            </div>
                            <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
                              <span>{formatDateBR(apt.date)}</span>
                              <span>•</span>
                              <Clock className="w-3 h-3" />
                              <span>{apt.start_time} - {apt.end_time}</span>
                              {apt.client_name && (
                                <>
                                  <span>•</span>
                                  <span>{apt.client_name}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full border ${STATUS_MAP[apt.status].badge}`}>
                          {STATUS_MAP[apt.status].label}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Clientes */}
              {filteredClients.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
                    <User className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Clientes ({filteredClients.length})</span>
                  </div>
                  <div className="space-y-1.5">
                    {filteredClients.map(c => (
                      <div
                        key={c.id}
                        onClick={() => {
                          onClose();
                          onSelectClient(c);
                        }}
                        className="p-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/80 cursor-pointer transition-colors flex items-center justify-between group border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-950/70 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold text-xs">
                            {c.name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="text-sm font-semibold text-slate-900 dark:text-white group-hover:text-emerald-600 transition-colors">
                              {c.name}
                            </div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">
                              {c.phone || c.email || 'Sem contato extra'}
                            </div>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition-colors" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tarefas */}
              {filteredTasks.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
                    <CheckSquare className="w-3.5 h-3.5 text-amber-500" />
                    <span>Tarefas ({filteredTasks.length})</span>
                  </div>
                  <div className="space-y-1.5">
                    {filteredTasks.map(t => (
                      <div
                        key={t.id}
                        onClick={() => {
                          onClose();
                          onSelectTask(t);
                        }}
                        className="p-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/80 cursor-pointer transition-colors flex items-center justify-between group border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-2 h-2 rounded-full ${t.completed ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                          <div>
                            <div className={`text-sm font-semibold text-slate-900 dark:text-white group-hover:text-amber-600 transition-colors ${t.completed ? 'line-through opacity-60' : ''}`}>
                              {t.title}
                            </div>
                            {t.due_date && (
                              <div className="text-xs text-slate-400">
                                Vencimento: {formatDateBR(t.due_date)} {t.due_time ? `às ${t.due_time}` : ''}
                              </div>
                            )}
                          </div>
                        </div>
                        <span className="text-[10px] font-semibold text-slate-400">
                          {t.priority}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Serviços */}
              {filteredServices.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
                    <Briefcase className="w-3.5 h-3.5 text-purple-500" />
                    <span>Serviços ({filteredServices.length})</span>
                  </div>
                  <div className="space-y-1.5">
                    {filteredServices.map(s => (
                      <div
                        key={s.id}
                        onClick={() => {
                          onClose();
                          onSelectService(s);
                        }}
                        className="p-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/80 cursor-pointer transition-colors flex items-center justify-between group border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
                      >
                        <div>
                          <div className="text-sm font-semibold text-slate-900 dark:text-white group-hover:text-purple-600 transition-colors">
                            {s.name}
                          </div>
                          <div className="text-xs text-slate-400">
                            {s.duration} min • R$ {s.price.toFixed(2)}
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-purple-600 transition-colors" />
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
