import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Calendar as CalendarIcon, 
  CheckSquare, 
  Users, 
  MoreHorizontal,
  Briefcase,
  Settings,
  Plus,
  X,
  Download,
  Target
} from 'lucide-react';
import { NavTab } from './Sidebar';
import { useData } from '../contexts/DataContext';
import { InstallAppButton } from './InstallAppButton';

interface BottomNavProps {
  currentTab: NavTab;
  setCurrentTab: (tab: NavTab) => void;
  onOpenNewAppointment: () => void;
  onOpenNewTask: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  setCurrentTab,
  onOpenNewAppointment,
  onOpenNewTask,
}) => {
  const { tasks } = useData();
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [showAddMenu, setShowAddMenu] = useState(false);

  const pendingTasks = tasks.filter(t => !t.completed).length;

  return (
    <>
      {/* Popover More Menu */}
      {showMoreMenu && (
        <div 
          className="fixed inset-0 z-40 bg-slate-950/40 backdrop-blur-xs md:hidden"
          onClick={() => setShowMoreMenu(false)}
        >
          <div 
            className="absolute bottom-18 right-4 w-52 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-2 space-y-1 animate-in slide-in-from-bottom-3"
            onClick={e => e.stopPropagation()}
          >
            <button
              onClick={() => {
                setCurrentTab('leads');
                setShowMoreMenu(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold ${
                currentTab === 'leads'
                  ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <Target className="w-4 h-4 text-emerald-500" />
              <span>Captura de Leads</span>
            </button>

            <button
              onClick={() => {
                setCurrentTab('services');
                setShowMoreMenu(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold ${
                currentTab === 'services'
                  ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <Briefcase className="w-4 h-4" />
              <span>Serviços Cadastrados</span>
            </button>
            <button
              onClick={() => {
                setCurrentTab('settings');
                setShowMoreMenu(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold ${
                currentTab === 'settings'
                  ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>Minha Agenda / Config</span>
            </button>

            <div className="pt-1 border-t border-slate-100 dark:border-slate-800">
              <InstallAppButton variant="sidebar" />
            </div>
          </div>
        </div>
      )}

      {/* Popover Quick Add Menu */}
      {showAddMenu && (
        <div 
          className="fixed inset-0 z-40 bg-slate-950/40 backdrop-blur-xs md:hidden"
          onClick={() => setShowAddMenu(false)}
        >
          <div 
            className="absolute bottom-20 left-1/2 -translate-x-1/2 w-64 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-3 space-y-2 animate-in slide-in-from-bottom-4"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-1 border-b border-slate-100 dark:border-slate-800">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Criar Novo</span>
              <button onClick={() => setShowAddMenu(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>
            <button
              onClick={() => {
                setShowAddMenu(false);
                onOpenNewAppointment();
              }}
              className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 font-semibold text-xs transition-colors"
            >
              <CalendarIcon className="w-4 h-4 text-indigo-600" />
              <span>Novo Compromisso</span>
            </button>
            <button
              onClick={() => {
                setShowAddMenu(false);
                onOpenNewTask();
              }}
              className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-slate-700 dark:text-slate-300 font-semibold text-xs transition-colors"
            >
              <CheckSquare className="w-4 h-4 text-amber-500" />
              <span>Nova Tarefa</span>
            </button>
          </div>
        </div>
      )}

      {/* Floating Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200/80 dark:border-slate-800 md:hidden pb-safe">
        <div className="flex items-center justify-around px-2 py-2">
          {/* Dashboard */}
          <button
            onClick={() => setCurrentTab('dashboard')}
            className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl text-[10px] font-medium transition-colors ${
              currentTab === 'dashboard'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
                : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
            }`}
          >
            <LayoutDashboard className="w-5 h-5" />
            <span>Início</span>
          </button>

          {/* Agenda */}
          <button
            onClick={() => setCurrentTab('calendar')}
            className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl text-[10px] font-medium transition-colors ${
              currentTab === 'calendar'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
                : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
            }`}
          >
            <CalendarIcon className="w-5 h-5" />
            <span>Agenda</span>
          </button>

          {/* Quick Add Floating Center Button */}
          <button
            onClick={() => setShowAddMenu(!showAddMenu)}
            aria-label="Criar novo"
            className="w-11 h-11 -mt-4 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg shadow-indigo-600/30 active:scale-95 transition-transform"
          >
            <Plus className="w-6 h-6" />
          </button>

          {/* Tarefas */}
          <button
            onClick={() => setCurrentTab('tasks')}
            className={`relative flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl text-[10px] font-medium transition-colors ${
              currentTab === 'tasks'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
                : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
            }`}
          >
            <CheckSquare className="w-5 h-5" />
            <span>Tarefas</span>
            {pendingTasks > 0 && (
              <span className="absolute top-0.5 right-1 w-2 h-2 rounded-full bg-indigo-600" />
            )}
          </button>

          {/* Clientes */}
          <button
            onClick={() => setCurrentTab('clients')}
            className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl text-[10px] font-medium transition-colors ${
              currentTab === 'clients'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
                : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
            }`}
          >
            <Users className="w-5 h-5" />
            <span>Clientes</span>
          </button>

          {/* Mais */}
          <button
            onClick={() => setShowMoreMenu(!showMoreMenu)}
            className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl text-[10px] font-medium transition-colors ${
              currentTab === 'services' || currentTab === 'settings'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
                : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
            }`}
          >
            <MoreHorizontal className="w-5 h-5" />
            <span>Mais</span>
          </button>
        </div>
      </nav>
    </>
  );
};
