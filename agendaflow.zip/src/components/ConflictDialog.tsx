import React from 'react';
import { AlertTriangle, Clock, Calendar as CalendarIcon, X } from 'lucide-react';
import { Appointment } from '../types';
import { formatDateBR } from '../lib/utils';

interface ConflictDialogProps {
  isOpen: boolean;
  conflictingAppointment: Appointment | null;
  onModifyTime: () => void;
  onSaveAnyway: () => void;
  onClose: () => void;
}

export const ConflictDialog: React.FC<ConflictDialogProps> = ({
  isOpen,
  conflictingAppointment,
  onModifyTime,
  onSaveAnyway,
  onClose,
}) => {
  if (!isOpen || !conflictingAppointment) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        role="dialog"
        aria-modal="true"
        className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-amber-200 dark:border-amber-900/50 p-6 overflow-hidden transform transition-all"
      >
        <div className="flex items-start gap-4">
          <div className="p-3 bg-amber-100 dark:bg-amber-900/40 text-amber-600 dark:text-amber-400 rounded-xl flex-shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Conflito de Horário Detectado
              </h3>
              <button
                onClick={onClose}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
              ⚠️ Já existe um compromisso agendado neste mesmo período:
            </p>

            <div className="mt-3 p-3.5 bg-amber-50/80 dark:bg-amber-950/30 rounded-xl border border-amber-200/80 dark:border-amber-900/30 text-xs text-slate-700 dark:text-slate-300 space-y-1.5">
              <div className="font-semibold text-slate-900 dark:text-white text-sm">
                {conflictingAppointment.title}
              </div>
              <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                <CalendarIcon className="w-3.5 h-3.5" />
                <span>{formatDateBR(conflictingAppointment.date)}</span>
                <span className="text-slate-300 dark:text-slate-700">•</span>
                <Clock className="w-3.5 h-3.5" />
                <span>{conflictingAppointment.start_time} - {conflictingAppointment.end_time}</span>
              </div>
              {conflictingAppointment.client_name && (
                <div className="text-slate-600 dark:text-slate-400">
                  Cliente: <span className="font-medium">{conflictingAppointment.client_name}</span>
                </div>
              )}
            </div>

            <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">
              Você pode voltar e alterar o horário ou salvar com sobreposição de horários caso seja proposital.
            </p>
          </div>
        </div>

        <div className="mt-6 flex flex-col-reverse sm:flex-row sm:justify-end gap-2.5">
          <button
            type="button"
            onClick={onSaveAnyway}
            className="px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors text-center"
          >
            Salvar mesmo assim
          </button>
          <button
            type="button"
            onClick={onModifyTime}
            className="px-4 py-2 text-sm font-semibold text-white bg-amber-600 hover:bg-amber-700 active:bg-amber-800 rounded-xl shadow-xs transition-all text-center"
          >
            Alterar horário
          </button>
        </div>
      </div>
    </div>
  );
};
