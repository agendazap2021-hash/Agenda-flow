import React, { useState, useEffect } from 'react';
import { 
  X, 
  Calendar as CalendarIcon, 
  Clock, 
  User, 
  Phone, 
  MapPin, 
  Briefcase, 
  Bell, 
  Trash2, 
  MessageSquare,
  Sparkles
} from 'lucide-react';
import { Appointment, AppointmentColor, AppointmentStatus, ReminderOption } from '../types';
import { useData } from '../contexts/DataContext';
import { 
  checkAppointmentConflict, 
  COLOR_MAP, 
  generateWhatsAppMessage, 
  getTodayString, 
  minutesToTime, 
  openWhatsApp, 
  REMINDER_MAP, 
  STATUS_MAP, 
  timeToMinutes 
} from '../lib/utils';
import { ConflictDialog } from './ConflictDialog';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialAppointment?: Appointment | null;
  defaultDate?: string;
  defaultTime?: string;
}

export const AppointmentModal: React.FC<AppointmentModalProps> = ({
  isOpen,
  onClose,
  initialAppointment,
  defaultDate,
  defaultTime,
}) => {
  const { appointments, clients, services, addAppointment, updateAppointment, deleteAppointment } = useData();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(defaultDate || getTodayString());
  const [startTime, setStartTime] = useState(defaultTime || '09:00');
  const [endTime, setEndTime] = useState('10:00');
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [serviceName, setServiceName] = useState('');
  const [location, setLocation] = useState('');
  const [status, setStatus] = useState<AppointmentStatus>('CONFIRMED');
  const [color, setColor] = useState<AppointmentColor>('blue');
  const [reminder, setReminder] = useState<ReminderOption>('15m');
  
  // Validation and conflict state
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [conflictingApt, setConflictingApt] = useState<Appointment | null>(null);
  const [showConflictDialog, setShowConflictDialog] = useState(false);

  useEffect(() => {
    if (initialAppointment) {
      setTitle(initialAppointment.title);
      setDescription(initialAppointment.description || '');
      setDate(initialAppointment.date);
      setStartTime(initialAppointment.start_time);
      setEndTime(initialAppointment.end_time);
      setClientName(initialAppointment.client_name || '');
      setClientPhone(initialAppointment.client_phone || '');
      setServiceName(initialAppointment.service_name || '');
      setLocation(initialAppointment.location || '');
      setStatus(initialAppointment.status);
      setColor(initialAppointment.color);
      setReminder(initialAppointment.reminder);
    } else {
      resetForm();
      if (defaultDate) setDate(defaultDate);
      if (defaultTime) {
        setStartTime(defaultTime);
        const startMins = timeToMinutes(defaultTime);
        setEndTime(minutesToTime(startMins + 60));
      }
    }
  }, [initialAppointment, defaultDate, defaultTime, isOpen]);

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setDate(defaultDate || getTodayString());
    setStartTime(defaultTime || '09:00');
    setEndTime(defaultTime ? minutesToTime(timeToMinutes(defaultTime) + 60) : '10:00');
    setClientName('');
    setClientPhone('');
    setServiceName('');
    setLocation('');
    setStatus('CONFIRMED');
    setColor('blue');
    setReminder('15m');
    setErrors({});
    setConflictingApt(null);
    setShowConflictDialog(false);
  };

  // When user picks a registered client from list
  const handleClientSelect = (selectedName: string) => {
    setClientName(selectedName);
    const found = clients.find(c => c.name.toLowerCase() === selectedName.toLowerCase());
    if (found && found.phone) {
      setClientPhone(found.phone);
    }
  };

  // When user picks a service from registered services list
  const handleServiceSelect = (selectedServiceName: string) => {
    setServiceName(selectedServiceName);
    const found = services.find(s => s.name === selectedServiceName);
    if (found && found.duration && startTime) {
      const startMins = timeToMinutes(startTime);
      const computedEnd = minutesToTime(startMins + found.duration);
      setEndTime(computedEnd);
    }
  };

  // When start time changes, automatically adjust end time to keep at least 30-60 min
  const handleStartTimeChange = (newStart: string) => {
    setStartTime(newStart);
    const startMins = timeToMinutes(newStart);
    const endMins = timeToMinutes(endTime);

    // If selected service has duration, apply it
    const selectedService = services.find(s => s.name === serviceName);
    const duration = selectedService ? selectedService.duration : 60;

    if (endMins <= startMins || Math.abs(endMins - startMins) > 180) {
      setEndTime(minutesToTime(startMins + duration));
    }
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};
    if (!title.trim()) newErrors.title = 'Título é obrigatório';
    if (!date) newErrors.date = 'Data é obrigatória';
    if (!startTime) newErrors.startTime = 'Hora inicial é obrigatória';
    if (!endTime) newErrors.endTime = 'Hora final é obrigatória';

    if (startTime && endTime) {
      const sMins = timeToMinutes(startTime);
      const eMins = timeToMinutes(endTime);
      if (eMins <= sMins) {
        newErrors.endTime = 'Hora final deve ser após o horário inicial';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleAttemptSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!validate()) return;

    // Check conflict
    const conflict = checkAppointmentConflict(
      {
        id: initialAppointment?.id,
        date,
        start_time: startTime,
        end_time: endTime,
      },
      appointments
    );

    if (conflict) {
      setConflictingApt(conflict);
      setShowConflictDialog(true);
      return;
    }

    executeSave();
  };

  const executeSave = async () => {
    setShowConflictDialog(false);
    const payload = {
      title: title.trim(),
      description: description.trim(),
      date,
      start_time: startTime,
      end_time: endTime,
      client_name: clientName.trim() || undefined,
      client_phone: clientPhone.trim() || undefined,
      service_name: serviceName.trim() || undefined,
      location: location.trim() || undefined,
      status,
      color,
      reminder,
    };

    if (initialAppointment) {
      await updateAppointment(initialAppointment.id, payload);
    } else {
      await addAppointment(payload);
    }
    onClose();
  };

  const handleDelete = async () => {
    if (!initialAppointment) return;
    if (window.confirm('Tem certeza que deseja excluir este compromisso?')) {
      await deleteAppointment(initialAppointment.id);
      onClose();
    }
  };

  const handleWhatsApp = () => {
    const fakeApt: Appointment = {
      id: initialAppointment?.id || 'temp',
      user_id: '',
      title: title || 'Compromisso',
      date,
      start_time: startTime,
      end_time: endTime,
      client_name: clientName,
      client_phone: clientPhone,
      status,
      color,
      reminder,
      created_at: '',
      updated_at: '',
    };
    const msg = generateWhatsAppMessage(fakeApt);
    openWhatsApp(clientPhone, msg);
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-40 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
        <div 
          role="dialog"
          aria-modal="true"
          className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6 transition-all"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className={`w-3.5 h-3.5 rounded-full ${COLOR_MAP[color].dot}`} />
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                {initialAppointment ? 'Editar Compromisso' : 'Novo Compromisso'}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleAttemptSave} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
            {/* Título */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Título do Compromisso *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="Ex: Reunião com cliente, Consulta, Alinhamento"
                className={`w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border rounded-xl text-slate-900 dark:text-white placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
                  errors.title ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                }`}
              />
              {errors.title && <p className="mt-1 text-xs text-rose-500">{errors.title}</p>}
            </div>

            {/* Data e Horários */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <CalendarIcon className="w-3.5 h-3.5" /> Data *
                  </span>
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" /> Início *
                  </span>
                </label>
                <input
                  type="time"
                  required
                  value={startTime}
                  onChange={e => handleStartTimeChange(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" /> Término *
                  </span>
                </label>
                <input
                  type="time"
                  required
                  value={endTime}
                  onChange={e => setEndTime(e.target.value)}
                  className={`w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border rounded-xl text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                    errors.endTime ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {errors.endTime && <p className="mt-1 text-xs text-rose-500">{errors.endTime}</p>}
              </div>
            </div>

            {/* Cliente e Telefone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5" /> Cliente
                  </span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    list="clients-list"
                    value={clientName}
                    onChange={e => handleClientSelect(e.target.value)}
                    placeholder="Selecione ou digite um nome..."
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <datalist id="clients-list">
                    {clients.map(c => (
                      <option key={c.id} value={c.name} />
                    ))}
                  </datalist>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5" /> Telefone / WhatsApp
                  </span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="tel"
                    value={clientPhone}
                    onChange={e => setClientPhone(e.target.value)}
                    placeholder="Ex: (11) 98765-4321"
                    className="flex-1 px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  {clientPhone && (
                    <button
                      type="button"
                      onClick={handleWhatsApp}
                      title="Enviar lembrete pelo WhatsApp"
                      className="px-3 bg-emerald-500 hover:bg-emerald-600 active:bg-emerald-700 text-white rounded-xl flex items-center justify-center transition-colors shadow-xs"
                    >
                      <MessageSquare className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Serviço e Local */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <Briefcase className="w-3.5 h-3.5" /> Serviço
                  </span>
                </label>
                <select
                  value={serviceName}
                  onChange={e => handleServiceSelect(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">Nenhum serviço específico</option>
                  {services.map(s => (
                    <option key={s.id} value={s.name}>
                      {s.name} ({s.duration} min - R$ {s.price.toFixed(2)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5" /> Local
                  </span>
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={e => setLocation(e.target.value)}
                  placeholder="Ex: Google Meet, Sala 02, Presencial"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Status e Lembrete */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                  Status
                </label>
                <select
                  value={status}
                  onChange={e => setStatus(e.target.value as AppointmentStatus)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="CONFIRMED">Confirmado</option>
                  <option value="PENDING">Pendente</option>
                  <option value="COMPLETED">Concluído</option>
                  <option value="CANCELLED">Cancelado</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <Bell className="w-3.5 h-3.5" /> Lembrete
                  </span>
                </label>
                <select
                  value={reminder}
                  onChange={e => setReminder(e.target.value as ReminderOption)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {Object.entries(REMINDER_MAP).map(([key, label]) => (
                    <option key={key} value={key}>
                      {label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Cores */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                Cor / Categoria
              </label>
              <div className="flex flex-wrap gap-2.5">
                {(Object.keys(COLOR_MAP) as AppointmentColor[]).map(cKey => {
                  const conf = COLOR_MAP[cKey];
                  const isSelected = color === cKey;
                  return (
                    <button
                      type="button"
                      key={cKey}
                      onClick={() => setColor(cKey)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                        isSelected
                          ? `${conf.badge} ring-2 ring-indigo-500 ring-offset-1 dark:ring-offset-slate-900 scale-105`
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-300'
                      }`}
                    >
                      <span className={`w-2.5 h-2.5 rounded-full ${conf.dot}`} />
                      {conf.name}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Descrição */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Anotações / Descrição
              </label>
              <textarea
                rows={2}
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Detalhes adicionais, pauta da reunião ou observações importantes..."
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Botões do Rodapé */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              {initialAppointment ? (
                <button
                  type="button"
                  onClick={handleDelete}
                  className="px-3 py-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl text-sm font-medium transition-colors flex items-center gap-1.5"
                >
                  <Trash2 className="w-4 h-4" />
                  <span className="hidden sm:inline">Excluir</span>
                </button>
              ) : (
                <div />
              )}

              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 rounded-xl shadow-xs hover:shadow-md transition-all flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Salvar compromisso</span>
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>

      {/* Conflict Dialog */}
      <ConflictDialog
        isOpen={showConflictDialog}
        conflictingAppointment={conflictingApt}
        onModifyTime={() => setShowConflictDialog(false)}
        onSaveAnyway={executeSave}
        onClose={() => setShowConflictDialog(false)}
      />
    </>
  );
};
