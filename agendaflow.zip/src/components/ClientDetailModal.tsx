import React from 'react';
import { 
  X, 
  Phone, 
  Mail, 
  FileText, 
  Calendar as CalendarIcon, 
  Clock, 
  MessageSquare, 
  Plus, 
  Edit, 
  User 
} from 'lucide-react';
import { Client, Appointment } from '../types';
import { useData } from '../contexts/DataContext';
import { COLOR_MAP, formatDateBR, getTodayString, openWhatsApp, STATUS_MAP } from '../lib/utils';

interface ClientDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  client: Client | null;
  onEdit: (client: Client) => void;
  onScheduleForClient: (client: Client) => void;
  onSelectAppointment: (apt: Appointment) => void;
}

export const ClientDetailModal: React.FC<ClientDetailModalProps> = ({
  isOpen,
  onClose,
  client,
  onEdit,
  onScheduleForClient,
  onSelectAppointment,
}) => {
  const { appointments } = useData();

  if (!isOpen || !client) return null;

  const today = getTodayString();
  
  // Filter appointments for this client
  const clientAppointments = appointments.filter(
    a => a.client_name?.trim().toLowerCase() === client.name.trim().toLowerCase() ||
         (client.phone && a.client_phone && a.client_phone.replace(/\D/g, '') === client.phone.replace(/\D/g, ''))
  );

  const upcomingAppointments = clientAppointments
    .filter(a => a.date >= today && a.status !== 'CANCELLED')
    .sort((a, b) => (a.date + a.start_time).localeCompare(b.date + b.start_time));

  const pastAppointments = clientAppointments
    .filter(a => a.date < today || a.status === 'COMPLETED' || a.status === 'CANCELLED')
    .sort((a, b) => (b.date + b.start_time).localeCompare(a.date + a.start_time));

  const handleWhatsApp = () => {
    openWhatsApp(
      client.phone,
      `Olá, ${client.name}! Tudo bem? Entrando em contato através da sua agenda AgendaFlow.`
    );
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        role="dialog"
        aria-modal="true"
        className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6 transition-all max-h-[90vh] flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-950/70 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-lg">
              {client.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                {client.name}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Ficha do Cliente • AgendaFlow
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onEdit(client)}
              className="p-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="Editar dados do cliente"
            >
              <Edit className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Quick Info & Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2.5 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800">
              <div className="flex items-center gap-2.5 text-sm text-slate-700 dark:text-slate-300">
                <Phone className="w-4 h-4 text-slate-400" />
                <span className="font-medium">{client.phone || 'Sem telefone cadastrado'}</span>
              </div>
              <div className="flex items-center gap-2.5 text-sm text-slate-700 dark:text-slate-300">
                <Mail className="w-4 h-4 text-slate-400" />
                <span className="truncate">{client.email || 'Sem e-mail cadastrado'}</span>
              </div>
            </div>

            <div className="flex flex-col justify-center gap-2.5">
              <button
                onClick={() => onScheduleForClient(client)}
                className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold flex items-center justify-center gap-2 shadow-xs transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Novo Agendamento</span>
              </button>
              {client.phone && (
                <button
                  onClick={handleWhatsApp}
                  className="w-full py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-colors shadow-xs"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Conversar no WhatsApp</span>
                </button>
              )}
            </div>
          </div>

          {/* Notes */}
          {client.notes && (
            <div className="p-4 rounded-xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/30">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-800 dark:text-amber-300 uppercase tracking-wider mb-1.5">
                <FileText className="w-3.5 h-3.5" />
                <span>Observações</span>
              </div>
              <p className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                {client.notes}
              </p>
            </div>
          )}

          {/* Próximos Compromissos */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3 flex items-center gap-2">
              <CalendarIcon className="w-4 h-4 text-indigo-500" />
              <span>Próximos Compromissos ({upcomingAppointments.length})</span>
            </h3>

            {upcomingAppointments.length === 0 ? (
              <p className="text-xs text-slate-400 p-4 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-center">
                Nenhum compromisso futuro agendado para este cliente.
              </p>
            ) : (
              <div className="space-y-2.5">
                {upcomingAppointments.map(apt => (
                  <div
                    key={apt.id}
                    onClick={() => {
                      onClose();
                      onSelectAppointment(apt);
                    }}
                    className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500 bg-white dark:bg-slate-800/60 transition-all cursor-pointer flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-2.5 h-8 rounded-full ${COLOR_MAP[apt.color].bg}`} />
                      <div>
                        <h4 className="text-sm font-semibold text-slate-900 dark:text-white group-hover:text-indigo-600 transition-colors">
                          {apt.title}
                        </h4>
                        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                          <span>{formatDateBR(apt.date)}</span>
                          <span>•</span>
                          <Clock className="w-3 h-3" />
                          <span>{apt.start_time} - {apt.end_time}</span>
                          {apt.service_name && (
                            <>
                              <span>•</span>
                              <span className="font-medium text-slate-600 dark:text-slate-300">{apt.service_name}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    <span className={`text-[11px] font-medium px-2.5 py-0.5 rounded-full border ${STATUS_MAP[apt.status].badge}`}>
                      {STATUS_MAP[apt.status].label}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Histórico Anterior */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3 flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-400" />
              <span>Histórico Passado ({pastAppointments.length})</span>
            </h3>

            {pastAppointments.length === 0 ? (
              <p className="text-xs text-slate-400 p-4 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-center">
                Nenhum histórico anterior registrado.
              </p>
            ) : (
              <div className="space-y-2">
                {pastAppointments.slice(0, 5).map(apt => (
                  <div
                    key={apt.id}
                    onClick={() => {
                      onClose();
                      onSelectAppointment(apt);
                    }}
                    className="p-3 rounded-xl border border-slate-100 dark:border-slate-800/80 bg-slate-50/60 dark:bg-slate-800/30 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer flex items-center justify-between"
                  >
                    <div>
                      <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                        {apt.title}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {formatDateBR(apt.date)} às {apt.start_time}
                      </div>
                    </div>
                    <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full border ${STATUS_MAP[apt.status].badge}`}>
                      {STATUS_MAP[apt.status].label}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
