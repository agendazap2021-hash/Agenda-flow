import React from 'react';
import { Search, Sun, Moon, Plus, Database, Sparkles } from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';
import { formatDateExtended, getTodayString } from '../lib/utils';
import { InstallAppButton } from './InstallAppButton';

interface HeaderProps {
  onOpenSearch: () => void;
  onOpenNewAppointment: () => void;
  onOpenSupabaseModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSearch,
  onOpenNewAppointment,
  onOpenSupabaseModal,
}) => {
  const { settings, updateSettings } = useData();
  const { isSupabaseConfigured, isDemoUser } = useAuth();

  const toggleTheme = () => {
    const nextTheme = settings.theme === 'dark' ? 'light' : 'dark';
    updateSettings({ theme: nextTheme });
  };

  const todayStr = getTodayString();
  const formattedToday = formatDateExtended(todayStr);

  return (
    <header className="sticky top-0 z-20 bg-white/85 dark:bg-slate-900/85 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 px-4 sm:px-6 py-3 transition-colors">
      <div className="flex items-center justify-between gap-4">
        {/* Left: Today's date with subtle indicator */}
        <div>
          <h1 className="text-sm font-bold text-slate-900 dark:text-white capitalize truncate">
            {formattedToday}
          </h1>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
            <span>AgendaFlow</span>
            <span>•</span>
            <span className="text-indigo-600 dark:text-indigo-400 font-medium">Pessoal & Profissional</span>
          </div>
        </div>

        {/* Center/Right: Global Search Button & Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Global Search trigger */}
          <button
            onClick={onOpenSearch}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-slate-500 dark:text-slate-400 text-xs font-medium transition-all group border border-transparent hover:border-slate-300 dark:hover:border-slate-600"
          >
            <Search className="w-3.5 h-3.5 text-indigo-500 group-hover:scale-110 transition-transform" />
            <span className="hidden sm:inline">Pesquisar...</span>
            <kbd className="hidden md:inline-block px-1.5 py-0.5 text-[10px] font-mono bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-700 text-slate-400 shadow-2xs">
              ⌘K
            </kbd>
          </button>

          {/* Supabase Status Chip on tablet/mobile */}
          <button
            onClick={onOpenSupabaseModal}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
              isSupabaseConfigured
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800'
                : 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800'
            }`}
            title="Status do banco Supabase"
          >
            <Database className="w-3.5 h-3.5" />
            <span className="hidden lg:inline text-[11px]">
              {isSupabaseConfigured ? 'Supabase Conectado' : 'Modo Demo'}
            </span>
          </button>

          {/* Theme Toggle Button */}
          <button
            onClick={toggleTheme}
            aria-label="Alternar tema"
            className="p-2 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            {settings.theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-slate-600" />
            )}
          </button>

          {/* Install App Button */}
          <InstallAppButton variant="compact" />

          {/* Quick Add Button */}
          <button
            onClick={onOpenNewAppointment}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Agendar</span>
          </button>
        </div>
      </div>
    </header>
  );
};
