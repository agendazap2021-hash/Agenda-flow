import React from 'react';
import { 
  LayoutDashboard, 
  Calendar as CalendarIcon, 
  CheckSquare, 
  Users, 
  Briefcase, 
  Settings, 
  Plus, 
  LogOut, 
  Sparkles, 
  Database,
  Target
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { InstallAppButton } from './InstallAppButton';

export type NavTab = 'dashboard' | 'calendar' | 'tasks' | 'clients' | 'leads' | 'services' | 'settings';

interface SidebarProps {
  currentTab: NavTab;
  setCurrentTab: (tab: NavTab) => void;
  onOpenNewAppointment: () => void;
  onOpenNewTask: () => void;
  onOpenSupabaseModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  setCurrentTab,
  onOpenNewAppointment,
  onOpenNewTask,
  onOpenSupabaseModal,
}) => {
  const { user, isDemoUser, isSupabaseConfigured, signOut } = useAuth();
  const { settings, appointments, tasks, clients } = useData();

  // Badge counts
  const pendingTasksCount = tasks.filter(t => !t.completed).length;
  const leadsCount = clients.length;

  const navItems = [
    { id: 'dashboard' as NavTab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'calendar' as NavTab, label: 'Agenda', icon: CalendarIcon },
    { id: 'tasks' as NavTab, label: 'Tarefas', icon: CheckSquare, badge: pendingTasksCount },
    { id: 'clients' as NavTab, label: 'Clientes', icon: Users },
    { id: 'leads' as NavTab, label: 'Captura de Leads (Adm)', icon: Target, badge: leadsCount },
    { id: 'services' as NavTab, label: 'Serviços', icon: Briefcase },
    { id: 'settings' as NavTab, label: 'Minha Agenda', icon: Settings },
  ];

  return (
    <aside className="hidden md:flex flex-col w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 h-screen sticky top-0 flex-shrink-0 select-none">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 text-white flex items-center justify-center shadow-md shadow-indigo-500/20">
            <CalendarIcon className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-base tracking-tight text-slate-900 dark:text-white">
                Agenda<span className="text-indigo-600 dark:text-indigo-400">Flow</span>
              </span>
            </div>
            <span className="text-[10px] font-semibold text-slate-400 tracking-wider uppercase">
              MiniFlow App
            </span>
          </div>
        </div>

        {/* Supabase Status Chip */}
        <button
          onClick={onOpenSupabaseModal}
          title={isSupabaseConfigured ? 'Supabase conectado' : 'Conectar Supabase'}
          className={`p-1.5 rounded-lg border text-xs transition-colors ${
            isSupabaseConfigured
              ? 'border-emerald-200 text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 dark:border-emerald-800'
              : 'border-slate-200 text-slate-400 hover:text-slate-600 dark:border-slate-700'
          }`}
        >
          <Database className="w-4 h-4" />
        </button>
      </div>

      {/* Action Buttons */}
      <div className="p-4 space-y-2">
        <button
          onClick={onOpenNewAppointment}
          className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-semibold text-sm shadow-sm hover:shadow-indigo-500/25 flex items-center justify-center gap-2 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Novo compromisso</span>
        </button>
        <button
          onClick={onOpenNewTask}
          className="w-full py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/60 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium text-xs flex items-center justify-center gap-1.5 transition-colors"
        >
          <CheckSquare className="w-3.5 h-3.5 text-indigo-500" />
          <span>Nova tarefa</span>
        </button>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-medium text-sm transition-all ${
                isActive
                  ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300 font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>
              {Boolean(item.badge && item.badge > 0) && (
                <span className="px-2 py-0.5 text-xs font-bold rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-900/60 dark:text-indigo-300">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* PWA Install Button */}
      <div className="p-3 border-t border-slate-100 dark:border-slate-800/80">
        <InstallAppButton variant="sidebar" />
      </div>

      {/* User Footer Profile */}
      <div className="p-4 border-t border-slate-100 dark:border-slate-800/80">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0">
            {settings.profile_photo ? (
              <img
                src={settings.profile_photo}
                alt={settings.name}
                className="w-8 h-8 rounded-full object-cover border border-slate-200 dark:border-slate-700"
              />
            ) : (
              <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 flex items-center justify-center font-bold text-xs">
                {(settings.name || user?.name || 'U').charAt(0).toUpperCase()}
              </div>
            )}
            <div className="min-w-0">
              <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
                {settings.name || user?.name || 'Minha Conta'}
              </p>
              <p className="text-[10px] text-slate-400 truncate">
                {isDemoUser ? 'Modo Demonstração' : user?.email || 'Conectado'}
              </p>
            </div>
          </div>
          <button
            onClick={() => signOut()}
            title="Sair da conta"
            className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
};
