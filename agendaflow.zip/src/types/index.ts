export type AppointmentStatus = 'PENDING' | 'CONFIRMED' | 'COMPLETED' | 'CANCELLED';

export type TaskPriority = 'LOW' | 'MEDIUM' | 'HIGH';

export type CalendarViewType = 'day' | 'week' | 'month' | 'list';

export type ThemeType = 'light' | 'dark' | 'system';

export type AppointmentColor = 
  | 'blue'     // Trabalho
  | 'green'    // Pessoal
  | 'yellow'   // Reunião
  | 'red'      // Urgente
  | 'purple'   // Atendimento
  | 'indigo'   // Geral
  | 'teal';    // Consulta

export type ReminderOption = 
  | 'none'
  | '5m'
  | '15m'
  | '30m'
  | '1h'
  | '1d';

export interface Appointment {
  id: string;
  user_id: string;
  title: string;
  description?: string;
  date: string; // YYYY-MM-DD
  start_time: string; // HH:mm
  end_time: string; // HH:mm
  client_name?: string;
  client_phone?: string;
  service_name?: string;
  location?: string;
  status: AppointmentStatus;
  color: AppointmentColor;
  reminder: ReminderOption;
  created_at: string;
  updated_at: string;
}

export interface Task {
  id: string;
  user_id: string;
  title: string;
  description?: string;
  due_date?: string; // YYYY-MM-DD
  due_time?: string; // HH:mm
  priority: TaskPriority;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

export interface Client {
  id: string;
  user_id: string;
  name: string;
  phone?: string;
  email?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface Service {
  id: string;
  user_id: string;
  name: string;
  description?: string;
  duration: number; // in minutes (e.g., 30, 45, 60)
  price: number; // e.g., 120.00
  created_at: string;
  updated_at: string;
}

export interface UserSettings {
  id: string;
  user_id: string;
  name: string;
  profile_photo?: string;
  phone?: string;
  email: string;
  theme: ThemeType;
  start_hour: string; // "08:00"
  end_hour: string; // "19:00"
  default_calendar_view: CalendarViewType;
  first_day_of_week: 'sunday' | 'monday';
  created_at: string;
  updated_at: string;
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
}
