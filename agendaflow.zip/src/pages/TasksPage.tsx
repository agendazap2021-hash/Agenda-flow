import React, { useState } from 'react';
import { 
  CheckSquare, 
  Plus, 
  Clock, 
  Calendar as CalendarIcon, 
  Filter, 
  Trash2, 
  Edit, 
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { Task, TaskPriority } from '../types';
import { formatDateBR, getTodayString, PRIORITY_MAP } from '../lib/utils';

interface TasksPageProps {
  onOpenNewTask: () => void;
  onSelectTask: (task: Task) => void;
}

type TaskFilterType = 'ALL' | 'TODAY' | 'PENDING' | 'COMPLETED' | 'HIGH';

export const TasksPage: React.FC<TasksPageProps> = ({
  onOpenNewTask,
  onSelectTask,
}) => {
  const { tasks, toggleTask, deleteTask } = useData();
  const [filter, setFilter] = useState<TaskFilterType>('ALL');
  const [search, setSearch] = useState('');

  const todayStr = getTodayString();

  const filteredTasks = tasks.filter(task => {
    // Search query
    if (search.trim()) {
      const q = search.toLowerCase();
      const match = task.title.toLowerCase().includes(q) || (task.description && task.description.toLowerCase().includes(q));
      if (!match) return false;
    }

    // Category filter
    if (filter === 'TODAY') {
      return task.due_date === todayStr;
    }
    if (filter === 'PENDING') {
      return !task.completed;
    }
    if (filter === 'COMPLETED') {
      return task.completed;
    }
    if (filter === 'HIGH') {
      return task.priority === 'HIGH';
    }
    return true;
  });

  const pendingCount = tasks.filter(t => !t.completed).length;
  const completedCount = tasks.filter(t => t.completed).length;

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-16">
      {/* Header and Add Task */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <span>Minhas Tarefas</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Organize afazeres pessoais e profissionais com prioridades e prazos
          </p>
        </div>

        <button
          onClick={onOpenNewTask}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-xs flex items-center gap-2 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ Nova Tarefa</span>
        </button>
      </div>

      {/* Filters and Search Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Quick Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            {[
              { id: 'ALL' as TaskFilterType, label: `Todas (${tasks.length})` },
              { id: 'TODAY' as TaskFilterType, label: 'Hoje' },
              { id: 'PENDING' as TaskFilterType, label: `Pendentes (${pendingCount})` },
              { id: 'COMPLETED' as TaskFilterType, label: `Concluídas (${completedCount})` },
              { id: 'HIGH' as TaskFilterType, label: 'Alta Prioridade' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setFilter(tab.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  filter === tab.id
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Search input */}
          <div className="w-full sm:w-64">
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar em tarefas..."
              className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* Task List */}
      <div className="space-y-2.5">
        {filteredTasks.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
            <CheckCircle2 className="w-10 h-10 mx-auto text-emerald-500 mb-2 opacity-60" />
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
              Nenhuma tarefa encontrada neste filtro
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Adicione uma tarefa ou selecione outra aba de visualização.
            </p>
            <button
              onClick={onOpenNewTask}
              className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition-colors"
            >
              + Adicionar primeira tarefa
            </button>
          </div>
        ) : (
          filteredTasks.map(task => {
            const priorityConf = PRIORITY_MAP[task.priority];

            return (
              <div
                key={task.id}
                className={`p-4 rounded-2xl border transition-all flex items-start justify-between gap-4 cursor-pointer group ${
                  task.completed
                    ? 'bg-slate-50/70 dark:bg-slate-900/40 border-slate-200/60 dark:border-slate-800 opacity-60'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-600 shadow-2xs'
                }`}
                onClick={() => onSelectTask(task)}
              >
                <div className="flex items-start gap-3.5 flex-1 min-w-0">
                  <input
                    type="checkbox"
                    checked={task.completed}
                    onChange={e => {
                      e.stopPropagation();
                      toggleTask(task.id);
                    }}
                    className="mt-1 w-4 h-4 text-indigo-600 rounded-sm focus:ring-indigo-500 cursor-pointer"
                  />

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`text-sm font-bold text-slate-900 dark:text-white ${task.completed ? 'line-through text-slate-400' : ''}`}>
                        {task.title}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${priorityConf.badge}`}>
                        {priorityConf.label}
                      </span>
                    </div>

                    {task.description && (
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                        {task.description}
                      </p>
                    )}

                    <div className="flex items-center gap-4 text-xs text-slate-400 mt-2">
                      {task.due_date && (
                        <div className="flex items-center gap-1 text-slate-600 dark:text-slate-300 font-medium">
                          <CalendarIcon className="w-3.5 h-3.5 text-indigo-500" />
                          <span>{formatDateBR(task.due_date)}</span>
                        </div>
                      )}
                      {task.due_time && (
                        <div className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{task.due_time}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={e => {
                      e.stopPropagation();
                      onSelectTask(task);
                    }}
                    className="p-1.5 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    title="Editar"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={e => {
                      e.stopPropagation();
                      if (window.confirm('Excluir esta tarefa?')) {
                        deleteTask(task.id);
                      }
                    }}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    title="Excluir"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
