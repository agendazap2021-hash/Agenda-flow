import React, { useState } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  Clock, 
  Plus, 
  Filter, 
  MapPin, 
  User, 
  MessageSquare,
  Sparkles,
  CheckCircle2,
  CalendarDays
} from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { Appointment, AppointmentColor, AppointmentStatus, CalendarViewType } from '../types';
import { 
  COLOR_MAP, 
  formatDateBR, 
  generateWhatsAppMessage, 
  getTodayString, 
  openWhatsApp, 
  STATUS_MAP, 
  timeToMinutes 
} from '../lib/utils';

interface CalendarPageProps {
  onOpenNewAppointment: (date?: string, time?: string) => void;
  onSelectAppointment: (apt: Appointment) => void;
}

export const CalendarPage: React.FC<CalendarPageProps> = ({
  onOpenNewAppointment,
  onSelectAppointment,
}) => {
  const { appointments, settings } = useData();

  // Navigation state
  const [currentDate, setCurrentDate] = useState(() => new Date());
  const [view, setView] = useState<CalendarViewType>(settings.default_calendar_view || 'week');
  const [statusFilter, setStatusFilter] = useState<'ALL' | AppointmentStatus>('ALL');
  const [colorFilter, setColorFilter] = useState<'ALL' | AppointmentColor>('ALL');

  const todayStr = getTodayString();

  // Navigation functions
  const handlePrev = () => {
    const next = new Date(currentDate);
    if (view === 'day') next.setDate(next.getDate() - 1);
    else if (view === 'week') next.setDate(next.getDate() - 7);
    else if (view === 'month') next.setMonth(next.getMonth() - 1);
    else next.setDate(next.getDate() - 30);
    setCurrentDate(next);
  };

  const handleNext = () => {
    const next = new Date(currentDate);
    if (view === 'day') next.setDate(next.getDate() + 1);
    else if (view === 'week') next.setDate(next.getDate() + 7);
    else if (view === 'month') next.setMonth(next.getMonth() + 1);
    else next.setDate(next.getDate() + 30);
    setCurrentDate(next);
  };

  const handleToday = () => {
    setCurrentDate(new Date());
  };

  // Filtered appointments
  const filteredAppointments = appointments.filter(apt => {
    if (statusFilter !== 'ALL' && apt.status !== statusFilter) return false;
    if (colorFilter !== 'ALL' && apt.color !== colorFilter) return false;
    return true;
  });

  // Helpers for current date representation
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const formattedMonthYear = currentDate.toLocaleDateString('pt-BR', {
    month: 'long',
    year: 'numeric',
  });

  // Calculate start of week (Sunday or Monday based on settings)
  const startDayOfWeek = settings.first_day_of_week === 'sunday' ? 0 : 1;
  const currentDayIndex = currentDate.getDay();
  const diffToStart = (currentDayIndex - startDayOfWeek + 7) % 7;
  const weekStart = new Date(currentDate);
  weekStart.setDate(currentDate.getDate() - diffToStart);

  const weekDays: Date[] = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(weekStart);
    d.setDate(weekStart.getDate() + i);
    weekDays.push(d);
  }

  // Work hours for Day / Week timeline
  const startHourNum = parseInt(settings.start_hour?.split(':')[0] || '8', 10);
  const endHourNum = parseInt(settings.end_hour?.split(':')[0] || '19', 10);
  const hoursRange: number[] = [];
  for (let h = startHourNum; h <= endHourNum; h++) {
    hoursRange.push(h);
  }

  const handleWhatsApp = (e: React.MouseEvent, apt: Appointment) => {
    e.stopPropagation();
    const msg = generateWhatsAppMessage(apt);
    openWhatsApp(apt.client_phone, msg);
  };

  // Format date helper (YYYY-MM-DD)
  const toDateString = (d: Date) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto pb-16">
      {/* Top Controls Bar */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        {/* Navigation buttons and title */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 p-0.5">
            <button
              onClick={handlePrev}
              title="Anterior"
              className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleToday}
              className="px-3 py-1 text-xs font-semibold hover:bg-white dark:hover:bg-slate-700 rounded-lg text-slate-700 dark:text-slate-200 transition-colors"
            >
              Hoje
            </button>
            <button
              onClick={handleNext}
              title="Próximo"
              className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300 transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <h2 className="text-base font-bold text-slate-900 dark:text-white capitalize flex items-center gap-2">
            <CalendarIcon className="w-4 h-4 text-indigo-500" />
            <span>{formattedMonthYear}</span>
          </h2>
        </div>

        {/* View mode switcher + New Appointment button */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="flex items-center bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl">
            {(['day', 'week', 'month', 'list'] as CalendarViewType[]).map(v => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={`px-3 py-1 text-xs font-semibold rounded-lg capitalize transition-all ${
                  view === v
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {v === 'day' ? 'Dia' : v === 'week' ? 'Semana' : v === 'month' ? 'Mês' : 'Lista'}
              </button>
            ))}
          </div>

          <button
            onClick={() => onOpenNewAppointment()}
            className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>+ Novo compromisso</span>
          </button>
        </div>
      </div>

      {/* Filter and Color Legend Strip */}
      <div className="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Status Filters */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-slate-400 font-semibold uppercase tracking-wider text-[10px] mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" /> Status:
          </span>
          <button
            onClick={() => setStatusFilter('ALL')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
              statusFilter === 'ALL'
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            Todos
          </button>
          <button
            onClick={() => setStatusFilter('CONFIRMED')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
              statusFilter === 'CONFIRMED'
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            Confirmados
          </button>
          <button
            onClick={() => setStatusFilter('PENDING')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
              statusFilter === 'PENDING'
                ? 'bg-amber-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            Pendentes
          </button>
          <button
            onClick={() => setStatusFilter('COMPLETED')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
              statusFilter === 'COMPLETED'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            Concluídos
          </button>
          <button
            onClick={() => setStatusFilter('CANCELLED')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
              statusFilter === 'CANCELLED'
                ? 'bg-slate-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            Cancelados
          </button>
        </div>

        {/* Color Legend / Filter */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-slate-400 font-semibold uppercase tracking-wider text-[10px] mr-1">
            Legenda:
          </span>
          {(['blue', 'green', 'yellow', 'red', 'purple'] as AppointmentColor[]).map(cKey => {
            const conf = COLOR_MAP[cKey];
            const isSelected = colorFilter === cKey;
            return (
              <button
                key={cKey}
                onClick={() => setColorFilter(isSelected ? 'ALL' : cKey)}
                title={`Filtrar por ${conf.name}`}
                className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] border transition-all ${
                  isSelected
                    ? `${conf.badge} ring-2 ring-indigo-500 font-bold`
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                }`}
              >
                <span className={`w-2 h-2 rounded-full ${conf.dot}`} />
                <span>{conf.name}</span>
              </button>
            );
          })}
          {colorFilter !== 'ALL' && (
            <button
              onClick={() => setColorFilter('ALL')}
              className="text-[10px] text-slate-400 hover:text-slate-600 underline ml-1"
            >
              Limpar cor
            </button>
          )}
        </div>
      </div>

      {/* View Component Render */}
      {view === 'day' && (
        <DayView
          currentDate={currentDate}
          hoursRange={hoursRange}
          appointments={filteredAppointments}
          onSelectAppointment={onSelectAppointment}
          onOpenNewAppointment={onOpenNewAppointment}
        />
      )}

      {view === 'week' && (
        <WeekView
          weekDays={weekDays}
          hoursRange={hoursRange}
          appointments={filteredAppointments}
          onSelectAppointment={onSelectAppointment}
          onOpenNewAppointment={onOpenNewAppointment}
        />
      )}

      {view === 'month' && (
        <MonthView
          currentDate={currentDate}
          appointments={filteredAppointments}
          onSelectAppointment={onSelectAppointment}
          onOpenNewAppointment={onOpenNewAppointment}
        />
      )}

      {view === 'list' && (
        <ListView
          appointments={filteredAppointments}
          onSelectAppointment={onSelectAppointment}
          onOpenNewAppointment={onOpenNewAppointment}
        />
      )}
    </div>
  );
};

/* =========================================================================
 * 1. DAY VIEW (Linha do Tempo Horária detalhada)
 * ========================================================================= */
const DayView: React.FC<{
  currentDate: Date;
  hoursRange: number[];
  appointments: Appointment[];
  onSelectAppointment: (apt: Appointment) => void;
  onOpenNewAppointment: (date?: string, time?: string) => void;
}> = ({ currentDate, hoursRange, appointments, onSelectAppointment, onOpenNewAppointment }) => {
  const y = currentDate.getFullYear();
  const m = String(currentDate.getMonth() + 1).padStart(2, '0');
  const d = String(currentDate.getDate()).padStart(2, '0');
  const dateStr = `${y}-${m}-${d}`;

  const dayAppointments = appointments.filter(a => a.date === dateStr);

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
      <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex items-center justify-between">
        <div>
          <h3 className="font-bold text-slate-900 dark:text-white capitalize text-base">
            {currentDate.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </h3>
          <p className="text-xs text-slate-400">
            {dayAppointments.length} compromisso{dayAppointments.length === 1 ? '' : 's'} agendado{dayAppointments.length === 1 ? '' : 's'}
          </p>
        </div>
        <button
          onClick={() => onOpenNewAppointment(dateStr, '09:00')}
          className="px-3 py-1.5 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 rounded-xl text-xs font-semibold hover:bg-indigo-100 transition-colors"
        >
          + Adicionar neste dia
        </button>
      </div>

      <div className="divide-y divide-slate-100 dark:divide-slate-800/70">
        {hoursRange.map(hour => {
          const hourStr = `${String(hour).padStart(2, '0')}:00`;
          const nextHourStr = `${String(hour + 1).padStart(2, '0')}:00`;
          
          // Appointments falling in this hour slot
          const slotAppointments = dayAppointments.filter(apt => {
            const aptMins = timeToMinutes(apt.start_time);
            return aptMins >= hour * 60 && aptMins < (hour + 1) * 60;
          });

          return (
            <div key={hour} className="flex min-h-[72px] group hover:bg-slate-50/70 dark:hover:bg-slate-800/30 transition-colors">
              {/* Hour Label */}
              <div className="w-18 sm:w-24 p-3 text-right text-xs font-bold text-slate-400 border-r border-slate-100 dark:border-slate-800 select-none flex flex-col justify-start">
                <span>{hourStr}</span>
              </div>

              {/* Event slot area */}
              <div 
                onClick={() => slotAppointments.length === 0 && onOpenNewAppointment(dateStr, hourStr)}
                className="flex-1 p-2 flex flex-col justify-center gap-2 cursor-pointer"
              >
                {slotAppointments.length === 0 ? (
                  <div className="h-full flex items-center text-xs text-slate-300 dark:text-slate-700 opacity-0 group-hover:opacity-100 transition-opacity pl-2">
                    + Clique para agendar às {hourStr}
                  </div>
                ) : (
                  slotAppointments.map(apt => {
                    const colorConf = COLOR_MAP[apt.color];
                    const statusConf = STATUS_MAP[apt.status];
                    return (
                      <div
                        key={apt.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectAppointment(apt);
                        }}
                        className={`p-3 rounded-xl border ${colorConf.badge} hover:scale-[1.01] transition-transform cursor-pointer shadow-2xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-2.5 h-7 rounded-full ${colorConf.dot}`} />
                          <div>
                            <div className="font-bold text-xs text-slate-900 dark:text-white flex items-center gap-2">
                              <span>{apt.title}</span>
                              <span className={`text-[10px] px-1.5 py-0.2 rounded-md ${statusConf.badge}`}>
                                {statusConf.label}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-3 mt-0.5">
                              <span className="font-semibold text-slate-700 dark:text-slate-300">
                                {apt.start_time} - {apt.end_time}
                              </span>
                              {apt.client_name && <span>Cliente: {apt.client_name}</span>}
                              {apt.location && <span>Local: {apt.location}</span>}
                            </div>
                          </div>
                        </div>

                        {apt.client_phone && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              const msg = generateWhatsAppMessage(apt);
                              openWhatsApp(apt.client_phone, msg);
                            }}
                            className="text-xs px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg flex items-center gap-1 self-start sm:self-center"
                          >
                            <MessageSquare className="w-3 h-3" />
                            <span>WhatsApp</span>
                          </button>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* =========================================================================
 * 2. WEEK VIEW (Grade Semanal com Horários Verticais)
 * ========================================================================= */
const WeekView: React.FC<{
  weekDays: Date[];
  hoursRange: number[];
  appointments: Appointment[];
  onSelectAppointment: (apt: Appointment) => void;
  onOpenNewAppointment: (date?: string, time?: string) => void;
}> = ({ weekDays, hoursRange, appointments, onSelectAppointment, onOpenNewAppointment }) => {
  const todayStr = getTodayString();

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-x-auto shadow-xs">
      <div className="min-w-[760px]">
        {/* Day Column Headers */}
        <div className="grid grid-cols-8 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 text-center">
          <div className="p-3 text-xs font-bold text-slate-400 border-r border-slate-200 dark:border-slate-800">
            Horário
          </div>
          {weekDays.map(d => {
            const dateStr = d.toISOString().split('T')[0];
            const isToday = dateStr === todayStr;
            const dayName = d.toLocaleDateString('pt-BR', { weekday: 'short' });
            const dayNum = d.getDate();

            return (
              <div
                key={dateStr}
                className={`p-2.5 border-r border-slate-200 dark:border-slate-800 last:border-r-0 ${
                  isToday ? 'bg-indigo-50/70 dark:bg-indigo-950/40 font-bold' : ''
                }`}
              >
                <div className={`text-[11px] uppercase tracking-wider ${isToday ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'}`}>
                  {dayName}
                </div>
                <div className={`text-base font-extrabold mt-0.5 ${isToday ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-800 dark:text-slate-200'}`}>
                  {dayNum}
                </div>
              </div>
            );
          })}
        </div>

        {/* Hourly Rows */}
        <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
          {hoursRange.map(hour => {
            const hourStr = `${String(hour).padStart(2, '0')}:00`;

            return (
              <div key={hour} className="grid grid-cols-8 min-h-[58px]">
                {/* Time Label */}
                <div className="p-2 text-right text-xs font-bold text-slate-400 border-r border-slate-100 dark:border-slate-800 select-none">
                  {hourStr}
                </div>

                {/* 7 Day slots */}
                {weekDays.map(d => {
                  const dateStr = d.toISOString().split('T')[0];
                  const slotApts = appointments.filter(apt => {
                    if (apt.date !== dateStr) return false;
                    const mins = timeToMinutes(apt.start_time);
                    return mins >= hour * 60 && mins < (hour + 1) * 60;
                  });

                  return (
                    <div
                      key={dateStr}
                      onClick={() => slotApts.length === 0 && onOpenNewAppointment(dateStr, hourStr)}
                      className="p-1 border-r border-slate-100 dark:border-slate-800/60 last:border-r-0 hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors cursor-pointer space-y-1"
                    >
                      {slotApts.map(apt => {
                        const colorConf = COLOR_MAP[apt.color];
                        return (
                          <div
                            key={apt.id}
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectAppointment(apt);
                            }}
                            className={`p-1.5 rounded-lg border text-[11px] ${colorConf.badge} truncate shadow-2xs hover:scale-[1.02] transition-transform`}
                            title={`${apt.title} (${apt.start_time} - ${apt.end_time})`}
                          >
                            <div className="font-bold truncate">{apt.title}</div>
                            <div className="text-[10px] opacity-80">{apt.start_time}</div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

/* =========================================================================
 * 3. MONTH VIEW (Grade Mensal com pequenos eventos dentro dos dias)
 * ========================================================================= */
const MonthView: React.FC<{
  currentDate: Date;
  appointments: Appointment[];
  onSelectAppointment: (apt: Appointment) => void;
  onOpenNewAppointment: (date?: string, time?: string) => void;
}> = ({ currentDate, appointments, onSelectAppointment, onOpenNewAppointment }) => {
  const todayStr = getTodayString();
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);

  const startDay = firstDay.getDay(); // 0 = Sun
  const totalDays = lastDay.getDate();

  // Days matrix
  const days: { dateStr: string; dayNum: number; isCurrentMonth: boolean }[] = [];

  // Previous month padding
  const prevMonthLast = new Date(year, month, 0).getDate();
  for (let i = startDay - 1; i >= 0; i--) {
    const dNum = prevMonthLast - i;
    const prevDate = new Date(year, month - 1, dNum);
    days.push({
      dateStr: prevDate.toISOString().split('T')[0],
      dayNum: dNum,
      isCurrentMonth: false,
    });
  }

  // Current month days
  for (let d = 1; d <= totalDays; d++) {
    const curDate = new Date(year, month, d);
    days.push({
      dateStr: curDate.toISOString().split('T')[0],
      dayNum: d,
      isCurrentMonth: true,
    });
  }

  // Next month padding to fill 35 or 42 grid cells
  const remaining = 35 - days.length > 0 ? 35 - days.length : 42 - days.length;
  for (let i = 1; i <= remaining; i++) {
    const nextDate = new Date(year, month + 1, i);
    days.push({
      dateStr: nextDate.toISOString().split('T')[0],
      dayNum: i,
      isCurrentMonth: false,
    });
  }

  const weekHeader = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
      {/* Week day names */}
      <div className="grid grid-cols-7 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 text-center">
        {weekHeader.map(name => (
          <div key={name} className="py-2.5 text-xs font-bold text-slate-500 uppercase tracking-wider">
            {name}
          </div>
        ))}
      </div>

      {/* Grid of Days */}
      <div className="grid grid-cols-7 divide-x divide-y divide-slate-100 dark:divide-slate-800/60">
        {days.map((cell, idx) => {
          const isToday = cell.dateStr === todayStr;
          const dayApts = appointments.filter(a => a.date === cell.dateStr);

          return (
            <div
              key={idx}
              onClick={() => onOpenNewAppointment(cell.dateStr)}
              className={`min-h-[100px] sm:min-h-[115px] p-2 transition-colors flex flex-col justify-between cursor-pointer group ${
                cell.isCurrentMonth
                  ? isToday
                    ? 'bg-indigo-50/40 dark:bg-indigo-950/20'
                    : 'bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  : 'bg-slate-50/30 dark:bg-slate-950/40 opacity-40 hover:opacity-70'
              }`}
            >
              <div className="flex items-center justify-between">
                <span
                  className={`text-xs font-bold w-6 h-6 flex items-center justify-center rounded-full ${
                    isToday
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {cell.dayNum}
                </span>

                {dayApts.length > 0 && (
                  <span className="text-[10px] font-semibold text-slate-400">
                    {dayApts.length}
                  </span>
                )}
              </div>

              {/* Events small badges */}
              <div className="mt-1 space-y-1 overflow-hidden flex-1">
                {dayApts.slice(0, 3).map(apt => {
                  const colorConf = COLOR_MAP[apt.color];
                  return (
                    <div
                      key={apt.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectAppointment(apt);
                      }}
                      className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md border truncate ${colorConf.badge} hover:scale-[1.02] transition-transform`}
                      title={`${apt.title} (${apt.start_time})`}
                    >
                      <span className="font-bold mr-1">{apt.start_time}</span>
                      <span>{apt.title}</span>
                    </div>
                  );
                })}
                {dayApts.length > 3 && (
                  <div className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 pl-1">
                    +{dayApts.length - 3} mais
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* =========================================================================
 * 4. LIST VIEW (Visão de Lista Ordenada)
 * ========================================================================= */
const ListView: React.FC<{
  appointments: Appointment[];
  onSelectAppointment: (apt: Appointment) => void;
  onOpenNewAppointment: () => void;
}> = ({ appointments, onSelectAppointment, onOpenNewAppointment }) => {
  const sorted = [...appointments].sort((a, b) => 
    (a.date + a.start_time).localeCompare(b.date + b.start_time)
  );

  // Group by date
  const grouped: Record<string, Appointment[]> = {};
  sorted.forEach(apt => {
    if (!grouped[apt.date]) grouped[apt.date] = [];
    grouped[apt.date].push(apt);
  });

  return (
    <div className="space-y-4">
      {Object.keys(grouped).length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
          <CalendarDays className="w-12 h-12 mx-auto text-slate-300 dark:text-slate-700 mb-3" />
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
            Nenhum compromisso encontrado para este filtro
          </p>
          <button
            onClick={() => onOpenNewAppointment()}
            className="mt-3 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold"
          >
            + Adicionar compromisso
          </button>
        </div>
      ) : (
        Object.entries(grouped).map(([dateStr, items]) => (
          <div key={dateStr} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
            <div className="px-5 py-3 bg-slate-50/70 dark:bg-slate-800/40 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <h3 className="font-bold text-xs uppercase tracking-wider text-slate-600 dark:text-slate-300 flex items-center gap-2">
                <CalendarIcon className="w-3.5 h-3.5 text-indigo-500" />
                <span>{formatDateBR(dateStr)}</span>
              </h3>
              <span className="text-xs text-slate-400 font-medium">
                {items.length} agendamento{items.length === 1 ? '' : 's'}
              </span>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800/60 p-2">
              {items.map(apt => {
                const colorConf = COLOR_MAP[apt.color];
                const statusConf = STATUS_MAP[apt.status];
                return (
                  <div
                    key={apt.id}
                    onClick={() => onSelectAppointment(apt)}
                    className="p-3.5 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors flex items-center justify-between gap-3 cursor-pointer group"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className={`w-2.5 h-10 rounded-full ${colorConf.bg}`} />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 transition-colors">
                            {apt.title}
                          </span>
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${statusConf.badge}`}>
                            {statusConf.label}
                          </span>
                        </div>
                        <div className="flex items-center flex-wrap gap-x-3 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                          <span className="font-semibold text-slate-700 dark:text-slate-300">
                            {apt.start_time} - {apt.end_time}
                          </span>
                          {apt.client_name && <span>Cliente: {apt.client_name}</span>}
                          {apt.service_name && <span>Serviço: {apt.service_name}</span>}
                          {apt.location && <span>Local: {apt.location}</span>}
                        </div>
                      </div>
                    </div>

                    {apt.client_phone && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          const msg = generateWhatsAppMessage(apt);
                          openWhatsApp(apt.client_phone, msg);
                        }}
                        className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 rounded-xl text-xs font-semibold flex items-center gap-1 border border-emerald-200 dark:border-emerald-800"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="hidden sm:inline">WhatsApp</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))
      )}
    </div>
  );
};
