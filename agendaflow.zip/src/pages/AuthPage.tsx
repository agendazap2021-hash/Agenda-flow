import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, 
  Mail, 
  Lock, 
  User, 
  ArrowRight, 
  Sparkles, 
  Database, 
  ShieldCheck, 
  Check, 
  AlertCircle,
  Phone,
  MessageSquare,
  Target,
  Clock,
  Send,
  LockKeyhole
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { InstallAppButton } from '../components/InstallAppButton';

interface AuthPageProps {
  onOpenSupabaseModal: () => void;
}

type AuthMode = 'lead' | 'login' | 'signup' | 'forgot';

export const AuthPage: React.FC<AuthPageProps> = ({ onOpenSupabaseModal }) => {
  const { signIn, signUp, registerPublicLead, resetPassword, loginAsDemo, isSupabaseConfigured } = useAuth();

  // 'lead' is the default mode! Visitors see the lead capture / appointment request form right away
  const [mode, setMode] = useState<AuthMode>('lead');
  
  // Lead / Signup fields
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [interest, setInterest] = useState('');
  
  // Login / Signup fields
  const [password, setPassword] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);
    setLoading(true);

    try {
      if (mode === 'lead') {
        // Capturar o lead na entrada
        const res = await registerPublicLead({
          name: name.trim(),
          phone: phone.trim() || undefined,
          email: email.trim() || undefined,
          notes: interest.trim() ? `Solicitação de horário/interesse: ${interest.trim()}` : 'Lead capturado na página inicial',
        });

        if (res.success) {
          setSuccessMessage('✅ Solicitação enviada com sucesso! Em breve entraremos em contato com você.');
          setName('');
          setPhone('');
          setEmail('');
          setInterest('');
        } else {
          setError(res.error || 'Não foi possível registrar o contato.');
        }
      } else if (mode === 'login') {
        const res = await signIn(email, password);
        if (res.error) {
          setError(res.error);
        }
      } else if (mode === 'signup') {
        const res = await signUp(email, password, name);
        if (res.error) {
          setError(res.error);
        } else if (res.message) {
          setSuccessMessage(res.message);
        }
      } else if (mode === 'forgot') {
        const res = await resetPassword(email);
        if (res.error) {
          setError(res.error);
        } else if (res.message) {
          setSuccessMessage(res.message);
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Erro inesperado.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-950 text-slate-100">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 text-slate-900 dark:text-white relative overflow-hidden">
        {/* Decorative Top Glow */}
        <div className="absolute -top-12 -right-12 w-40 h-40 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Brand */}
        <div className="text-center mb-5">
          <div className="inline-flex p-3 rounded-2xl bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 mb-2.5">
            <CalendarIcon className="w-7 h-7" />
          </div>
          <h1 className="text-2xl font-black tracking-tight">
            Agenda<span className="text-indigo-600 dark:text-indigo-400">Flow</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {mode === 'lead' 
              ? 'Agende seu horário ou solicite atendimento com nossa equipe'
              : 'Painel Administrativo da sua Agenda'}
          </p>
        </div>

        {/* Tabs: Agendar / Contato (Público) vs Área Administrativa */}
        <div className="flex bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl mb-5">
          <button
            type="button"
            onClick={() => {
              setMode('lead');
              setError(null);
              setSuccessMessage(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              mode === 'lead'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Agendar Horário / Contato</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setMode('login');
              setError(null);
              setSuccessMessage(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              mode !== 'lead'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs font-extrabold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <LockKeyhole className="w-3.5 h-3.5" />
            <span>Área do Administrador</span>
          </button>
        </div>

        {/* Feedback alerts */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2 dark:bg-rose-950/40 dark:border-rose-900 dark:text-rose-300">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {successMessage && (
          <div className="mb-4 p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs flex items-start gap-2.5 dark:bg-emerald-950/40 dark:border-emerald-900 dark:text-emerald-300">
            <Check className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* ======================================================== */}
        {/* CASO 1: MODO CAPTURA DE LEADS (PÚBLICO PARA VISITANTES)   */}
        {/* ======================================================== */}
        {mode === 'lead' && (
          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div className="p-3 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-800/60 mb-2">
              <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 block mb-0.5">
                📝 Preencha seus dados abaixo:
              </span>
              <p className="text-[11px] text-emerald-700 dark:text-emerald-400">
                Seus dados serão enviados diretamente para nossa equipe confirmar o melhor horário de atendimento com você.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Seu Nome Completo *
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="Ex: João da Silva"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                WhatsApp / Celular com DDD *
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="Ex: (11) 98765-4321"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Seu E-mail (Opcional)
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="seuemail@exemplo.com"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Qual serviço ou horário de interesse?
              </label>
              <textarea
                rows={2}
                value={interest}
                onChange={e => setInterest(e.target.value)}
                placeholder="Ex: Gostaria de atendimento na quinta-feira à tarde / Orçamento para consultoria..."
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-sm rounded-xl shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2"
            >
              <span>{loading ? 'Enviando dados...' : 'Enviar e Solicitar Horário'}</span>
              <Send className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* ======================================================== */}
        {/* CASO 2: MODO ADMINISTRADOR (LOGIN / CRIAR CONTA)          */}
        {/* ======================================================== */}
        {mode !== 'lead' && (
          <form onSubmit={handleSubmit} className="space-y-3.5">
            {/* Sub-tabs login vs signup */}
            <div className="flex bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl mb-3">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError(null);
                  setSuccessMessage(null);
                }}
                className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
                  mode === 'login'
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                Entrar como Admin
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('signup');
                  setError(null);
                  setSuccessMessage(null);
                }}
                className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
                  mode === 'signup'
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                Criar Nova Conta
              </button>
            </div>

            {mode === 'signup' && (
              <div>
                <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                  Nome do Administrador
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="Seu nome completo"
                    className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                E-mail de Acesso
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="admin@exemplo.com"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {mode !== 'forgot' && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400">
                    Senha
                  </label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => {
                        setMode('forgot');
                        setError(null);
                        setSuccessMessage(null);
                      }}
                      className="text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline"
                    >
                      Esqueceu a senha?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-bold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
            >
              <span>
                {loading
                  ? 'Processando...'
                  : mode === 'login'
                  ? 'Entrar no Painel Admin'
                  : mode === 'signup'
                  ? 'Criar Conta Admin'
                  : 'Recuperar Senha'}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* Demo Fast Login for Admin */}
        <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 text-center">
          <button
            type="button"
            onClick={loginAsDemo}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-slate-800 dark:text-slate-200 text-xs font-bold transition-colors flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-indigo-500" />
            <span>Entrar como Administrador (Éder)</span>
          </button>
          <p className="text-[10px] text-slate-400 mt-2">
            Acesso administrativo liberado para <strong>netcellinfo@gmail.com</strong>
          </p>
        </div>

        {/* Install App Link */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-center">
          <InstallAppButton variant="button" className="w-full justify-center" />
        </div>
      </div>
    </div>
  );
};
