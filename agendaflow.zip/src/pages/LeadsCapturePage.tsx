import React, { useState } from 'react';
import { 
  Users, 
  Share2, 
  ExternalLink, 
  Copy, 
  Check, 
  Download, 
  Smartphone, 
  Globe, 
  MessageSquare, 
  Plus, 
  Calendar as CalendarIcon, 
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Zap,
  TrendingUp,
  UserPlus
} from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { Client } from '../types';
import { openWhatsApp } from '../lib/utils';

interface LeadsCapturePageProps {
  onOpenNewClient: () => void;
  onSelectClient: (client: Client) => void;
  onOpenNewAppointment: () => void;
}

export const LeadsCapturePage: React.FC<LeadsCapturePageProps> = ({
  onOpenNewClient,
  onSelectClient,
  onOpenNewAppointment,
}) => {
  const { clients, appointments, services, settings, addClient } = useData();
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedBio, setCopiedBio] = useState(false);
  const [filterQuery, setFilterQuery] = useState('');

  // Quick Lead Capture Form in the page
  const [leadName, setLeadName] = useState('');
  const [leadPhone, setLeadPhone] = useState('');
  const [leadEmail, setLeadEmail] = useState('');
  const [leadInterest, setLeadInterest] = useState('');
  const [captureSuccess, setCaptureSuccess] = useState(false);

  // Stats
  const totalLeads = clients.length;
  const leadsWithPhone = clients.filter(c => Boolean(c.phone)).length;
  const leadsWithEmail = clients.filter(c => Boolean(c.email)).length;

  // Standalone public link to send to clients
  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : '';
  const publicBookingUrl = `${currentOrigin}/agendaflow_completo.html`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(publicBookingUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleCopyBioText = () => {
    const bioText = `📅 Agende seu horário comigo ou solicite atendimento online pelo link:\n👉 ${publicBookingUrl}`;
    navigator.clipboard.writeText(bioText);
    setCopiedBio(true);
    setTimeout(() => setCopiedBio(false), 2500);
  };

  // Quick register lead
  const handleQuickLeadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leadName.trim()) return;

    await addClient({
      name: leadName.trim(),
      phone: leadPhone.trim() || undefined,
      email: leadEmail.trim() || undefined,
      notes: leadInterest.trim() ? `Interesse: ${leadInterest.trim()}` : 'Capturado via formulário rápido',
    });

    setLeadName('');
    setLeadPhone('');
    setLeadEmail('');
    setLeadInterest('');
    setCaptureSuccess(true);
    setTimeout(() => setCaptureSuccess(false), 3000);
  };

  // Export CSV
  const handleExportCSV = () => {
    if (clients.length === 0) {
      alert('Nenhum lead/contato para exportar.');
      return;
    }

    const headers = ['Nome', 'WhatsApp / Telefone', 'E-mail', 'Interesse / Notas', 'Data de Cadastro'];
    const rows = clients.map(c => [
      `"${(c.name || '').replace(/"/g, '""')}"`,
      `"${(c.phone || '').replace(/"/g, '""')}"`,
      `"${(c.email || '').replace(/"/g, '""')}"`,
      `"${(c.notes || '').replace(/"/g, '""')}"`,
      `"${new Date(c.created_at).toLocaleDateString('pt-BR')}"`,
    ]);

    const csvContent = '\uFEFF' + [headers.join(';'), ...rows.map(r => r.join(';'))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `leads_capturados_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const filteredLeads = clients.filter(c => {
    const q = filterQuery.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      (c.phone && c.phone.includes(q)) ||
      (c.email && c.email.toLowerCase().includes(q)) ||
      (c.notes && c.notes.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-16">
      {/* Top Hero Banner: Captura de Leads */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-indigo-950 text-white p-6 sm:p-8 rounded-3xl shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-3">
            <Zap className="w-3.5 h-3.5" />
            <span>Motor de Conversão & Captura de Clientes</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            Central de Captura de Leads & Clientes
          </h2>
          <p className="text-xs sm:text-sm text-emerald-100/80 mt-2 leading-relaxed">
            Compartilhe seu link exclusivo com novos clientes, capture contatos diretamente pelas redes sociais (Instagram, WhatsApp, Google) e exporte a lista pronta para Excel a qualquer momento!
          </p>

          <div className="flex flex-wrap items-center gap-2.5 mt-5">
            <button
              onClick={handleCopyLink}
              className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 text-emerald-950 font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-2"
            >
              {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copiedLink ? 'Link Copiado!' : 'Copiar Link de Agendamento'}</span>
            </button>

            <button
              onClick={handleCopyBioText}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold text-xs rounded-xl transition-all flex items-center gap-2"
            >
              {copiedBio ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
              <span>{copiedBio ? 'Texto Copiado!' : 'Copiar Texto para Bio do Instagram'}</span>
            </button>

            <a
              href="/agendaflow_completo.html"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-2.5 bg-black/20 hover:bg-black/40 text-emerald-200 hover:text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Ver Página Pública</span>
            </a>

            <a
              href="/agendaflow_completo.html"
              download="agendaflow_completo.html"
              className="px-3.5 py-2.5 bg-white text-emerald-950 hover:bg-emerald-50 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-md transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Baixar Arquivo HTML Completo</span>
            </a>
          </div>
        </div>

        {/* Decorative background glow */}
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Total de Leads</span>
            <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
            {totalLeads}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Contatos na sua base</span>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Com WhatsApp</span>
            <div className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950/50 text-teal-600 dark:text-teal-400">
              <Smartphone className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-teal-600 dark:text-teal-400 mt-1">
            {leadsWithPhone}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Prontos para contato</span>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Com E-mail</span>
            <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400">
              <Globe className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-indigo-600 dark:text-indigo-400 mt-1">
            {leadsWithEmail}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Contatos com e-mail</span>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Agendamentos</span>
            <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400">
              <CalendarIcon className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
            {appointments.length}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Compromissos criados</span>
        </div>
      </div>

      {/* 2 Columns: Formulário Rápido de Captura + Ações de Divulgação */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Coluna 1 & 2: Formulário de Captura Rápida de Lead */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                <UserPlus className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  Cadastrar Lead Manualmente
                </h3>
                <p className="text-xs text-slate-400">
                  Adicione novos contatos recebidos por WhatsApp, Instagram ou ligação
                </p>
              </div>
            </div>

            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold hover:bg-emerald-100 transition-colors flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Exportar Excel</span>
            </button>
          </div>

          {captureSuccess && (
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl text-emerald-700 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
              <Check className="w-4 h-4" />
              <span>Lead cadastrado com sucesso na sua base!</span>
            </div>
          )}

          <form onSubmit={handleQuickLeadSubmit} className="space-y-3.5 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Nome do Lead / Cliente *
                </label>
                <input
                  type="text"
                  required
                  value={leadName}
                  onChange={e => setLeadName(e.target.value)}
                  placeholder="Ex: Amanda Souza"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  WhatsApp / Telefone
                </label>
                <input
                  type="tel"
                  value={leadPhone}
                  onChange={e => setLeadPhone(e.target.value)}
                  placeholder="Ex: (11) 98765-4321"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  E-mail
                </label>
                <input
                  type="email"
                  value={leadEmail}
                  onChange={e => setLeadEmail(e.target.value)}
                  placeholder="Ex: amanda@exemplo.com"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Interesse / Serviço de Busca
                </label>
                <input
                  type="text"
                  value={leadInterest}
                  onChange={e => setLeadInterest(e.target.value)}
                  placeholder="Ex: Consulta, Orçamento, Pacote"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end pt-1">
              <button
                type="submit"
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white rounded-xl font-bold shadow-xs transition-colors flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Salvar Lead na Base</span>
              </button>
            </div>
          </form>
        </div>

        {/* Coluna 3: Dicas e Como Divulgar */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>Como Atrair Mais Leads</span>
          </h3>

          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="font-bold text-indigo-600 dark:text-indigo-400 block mb-1">
                1. Bio do Instagram
              </span>
              <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                Coloque seu link de agendamento na Bio. Os seguidores clicam e preenchem os dados para falar com você.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="font-bold text-emerald-600 dark:text-emerald-400 block mb-1">
                2. Resposta Rápida no WhatsApp
              </span>
              <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                Configure uma mensagem de saudação automática enviando seu link para o cliente escolher o horário.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="font-bold text-teal-600 dark:text-teal-400 block mb-1">
                3. Exportação para Campanhas
              </span>
              <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                Baixe a planilha CSV e suba seus leads em disparadores de mensagens ou listas de transmissão.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabela de Leads Capturados com Ação de WhatsApp Direto */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Leads & Contatos Atuais ({filteredLeads.length})
            </h3>
            <p className="text-xs text-slate-400">
              Clique para ver detalhes, agendar compromissos ou iniciar conversa direta no WhatsApp
            </p>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={filterQuery}
              onChange={e => setFilterQuery(e.target.value)}
              placeholder="Filtrar por nome, fone, notas..."
              className="px-3.5 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button
              onClick={handleExportCSV}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs whitespace-nowrap transition-colors flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Baixar Planilha</span>
            </button>
          </div>
        </div>

        {filteredLeads.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-slate-200 dark:border-slate-800 rounded-2xl">
            <Users className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
            <h4 className="font-bold text-sm text-slate-700 dark:text-slate-300">Nenhum lead encontrado</h4>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Cadastre um lead acima ou compartilhe seu link público para receber novos contatos!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredLeads.map(lead => (
              <div
                key={lead.id}
                onClick={() => onSelectClient(lead)}
                className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-600 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-white dark:hover:bg-slate-800/80 transition-all cursor-pointer flex flex-col justify-between group shadow-2xs"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] font-extrabold uppercase tracking-wide">
                      Lead Ativo
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {new Date(lead.created_at).toLocaleDateString('pt-BR')}
                    </span>
                  </div>

                  <h4 className="font-bold text-sm text-slate-900 dark:text-white group-hover:text-indigo-600 transition-colors">
                    {lead.name}
                  </h4>

                  <div className="mt-2 space-y-1 text-xs text-slate-500 dark:text-slate-400">
                    <p className="flex items-center gap-1.5">
                      <span>📞</span>
                      <span className="font-medium text-slate-700 dark:text-slate-300">
                        {lead.phone || 'Sem telefone'}
                      </span>
                    </p>
                    {lead.email && (
                      <p className="flex items-center gap-1.5 truncate">
                        <span>✉️</span>
                        <span>{lead.email}</span>
                      </p>
                    )}
                    {lead.notes && (
                      <p className="text-[11px] text-slate-400 italic bg-white dark:bg-slate-900 p-2 rounded-xl mt-2 border border-slate-100 dark:border-slate-800 line-clamp-2">
                        "{lead.notes}"
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-200/70 dark:border-slate-700/60">
                  {lead.phone ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openWhatsApp(
                          lead.phone,
                          `Olá, ${lead.name}! Vi que você tem interesse em nossos serviços. Como posso te ajudar hoje?`
                        );
                      }}
                      className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-transform active:scale-95"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Falar no WhatsApp</span>
                    </button>
                  ) : (
                    <span className="text-[11px] text-slate-400 italic">Sem WhatsApp</span>
                  )}

                  <span className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
                    Detalhes <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
