import React, { useState } from 'react';
import { 
  Users, 
  Plus, 
  Search, 
  Phone, 
  Mail, 
  MessageSquare, 
  ChevronRight, 
  Calendar as CalendarIcon,
  Trash2,
  Edit,
  Download,
  Share2,
  FileSpreadsheet,
  CheckCircle2
} from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { Client } from '../types';
import { openWhatsApp } from '../lib/utils';

interface ClientsPageProps {
  onOpenNewClient: () => void;
  onSelectClient: (client: Client) => void;
  onEditClient: (client: Client) => void;
}

export const ClientsPage: React.FC<ClientsPageProps> = ({
  onOpenNewClient,
  onSelectClient,
  onEditClient,
}) => {
  const { clients, appointments, deleteClient } = useData();
  const [search, setSearch] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);

  const filteredClients = clients.filter(c => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      (c.phone && c.phone.includes(q)) ||
      (c.email && c.email.toLowerCase().includes(q)) ||
      (c.notes && c.notes.toLowerCase().includes(q))
    );
  });

  const handleWhatsApp = (e: React.MouseEvent, client: Client) => {
    e.stopPropagation();
    openWhatsApp(
      client.phone,
      `Olá, ${client.name}! Tudo bem? Estou entrando em contato sobre os seus agendamentos.`
    );
  };

  // Exportar leads para arquivo CSV
  const handleExportCSV = () => {
    if (clients.length === 0) {
      alert('Nenhum lead/cliente cadastrado para exportar.');
      return;
    }

    const headers = ['Nome', 'Telefone / WhatsApp', 'E-mail', 'Observações', 'Cadastrado Em'];
    const rows = clients.map(c => [
      `"${(c.name || '').replace(/"/g, '""')}"`,
      `"${(c.phone || '').replace(/"/g, '""')}"`,
      `"${(c.email || '').replace(/"/g, '""')}"`,
      `"${(c.notes || '').replace(/"/g, '""')}"`,
      `"${new Date(c.created_at).toLocaleDateString('pt-BR')}"`,
    ]);

    const csvContent = '\uFEFF' + [headers.join(';'), ...rows.map(r => r.join(';'))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `leads_agendaflow_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <span>Meus Clientes & Leads ({clients.length})</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Base de contatos capturados, clientes e leads para envio de mensagens e acompanhamento
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleExportCSV}
            title="Exportar base de contatos em planilha CSV (Excel)"
            className="px-3 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-200 dark:border-slate-700"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>Exportar Leads (Excel/CSV)</span>
          </button>

          <button
            onClick={onOpenNewClient}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-xs flex items-center gap-2 transition-all self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>+ Novo Cliente / Lead</span>
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Pesquisar por nome, telefone ou e-mail..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Clients Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredClients.length === 0 ? (
          <div className="sm:col-span-2 lg:col-span-3 p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
            <Users className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
              Nenhum cliente encontrado
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Cadastre novos clientes para facilitar o preenchimento dos compromissos.
            </p>
            <button
              onClick={onOpenNewClient}
              className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition-colors"
            >
              + Adicionar primeiro cliente
            </button>
          </div>
        ) : (
          filteredClients.map(client => {
            // Count client's total appointments
            const clientAptsCount = appointments.filter(
              a => a.client_name?.trim().toLowerCase() === client.name.trim().toLowerCase()
            ).length;

            return (
              <div
                key={client.id}
                onClick={() => onSelectClient(client)}
                className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-600 shadow-2xs hover:shadow-xs transition-all cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-950/70 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-sm">
                        {client.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <h3 className="font-bold text-sm text-slate-900 dark:text-white group-hover:text-indigo-600 transition-colors">
                          {client.name}
                        </h3>
                        <div className="flex items-center gap-1 text-[11px] text-slate-400">
                          <CalendarIcon className="w-3 h-3" />
                          <span>{clientAptsCount} agendamento{clientAptsCount === 1 ? '' : 's'}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={e => {
                          e.stopPropagation();
                          onEditClient(client);
                        }}
                        className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg transition-colors"
                        title="Editar cliente"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                    {client.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                        <span>{client.phone}</span>
                      </div>
                    )}
                    {client.email && (
                      <div className="flex items-center gap-2">
                        <Mail className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                        <span className="truncate">{client.email}</span>
                      </div>
                    )}
                    {client.notes && (
                      <p className="text-[11px] text-slate-400 line-clamp-2 pt-1">
                        {client.notes}
                      </p>
                    )}
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                  {client.phone ? (
                    <button
                      type="button"
                      onClick={e => handleWhatsApp(e, client)}
                      className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-semibold flex items-center gap-1.5 border border-emerald-200 dark:border-emerald-800"
                    >
                      <MessageSquare className="w-3 h-3 text-emerald-600" />
                      <span>WhatsApp</span>
                    </button>
                  ) : (
                    <div />
                  )}

                  <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 group-hover:translate-x-1 transition-transform flex items-center gap-0.5">
                    Ver ficha <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
