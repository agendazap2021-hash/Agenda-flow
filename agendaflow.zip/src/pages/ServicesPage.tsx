import React, { useState } from 'react';
import { 
  Briefcase, 
  Plus, 
  Clock, 
  DollarSign, 
  Edit, 
  Trash2, 
  Search,
  Sparkles
} from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { Service } from '../types';
import { formatCurrency } from '../lib/utils';

interface ServicesPageProps {
  onOpenNewService: () => void;
  onEditService: (service: Service) => void;
}

export const ServicesPage: React.FC<ServicesPageProps> = ({
  onOpenNewService,
  onEditService,
}) => {
  const { services, deleteService } = useData();
  const [search, setSearch] = useState('');

  const filteredServices = services.filter(s => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return s.name.toLowerCase().includes(q) || (s.description && s.description.toLowerCase().includes(q));
  });

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <span>Serviços & Procedimentos</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Cadastre durações e valores para preenchimento automático de compromissos
          </p>
        </div>

        <button
          onClick={onOpenNewService}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-xs flex items-center gap-2 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ Novo Serviço</span>
        </button>
      </div>

      {/* Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Pesquisar por serviço..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Services List */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {filteredServices.length === 0 ? (
          <div className="sm:col-span-2 p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
            <Briefcase className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
              Nenhum serviço cadastrado
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Cadastre seus atendimentos, consultas ou procedimentos com tempo e preço.
            </p>
            <button
              onClick={onOpenNewService}
              className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition-colors"
            >
              + Adicionar primeiro serviço
            </button>
          </div>
        ) : (
          filteredServices.map(service => (
            <div
              key={service.id}
              className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-600 shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <h3 className="font-bold text-base text-slate-900 dark:text-white">
                    {service.name}
                  </h3>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onEditService(service)}
                      className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg transition-colors"
                      title="Editar serviço"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm(`Excluir o serviço "${service.name}"?`)) {
                          deleteService(service.id);
                        }
                      }}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition-colors"
                      title="Excluir serviço"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {service.description && (
                  <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 line-clamp-2">
                    {service.description}
                  </p>
                )}
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 font-medium">
                  <Clock className="w-4 h-4 text-indigo-500" />
                  <span>{service.duration} minutos</span>
                </div>

                <div className="text-base font-extrabold text-emerald-600 dark:text-emerald-400">
                  {formatCurrency(service.price)}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
