import React, { useState } from 'react';
import { 
  Settings, 
  User, 
  Phone, 
  Mail, 
  Clock, 
  Calendar as CalendarIcon, 
  Moon, 
  Sun, 
  Monitor, 
  Database, 
  Check, 
  Sparkles,
  Save,
  ShieldCheck
} from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';
import { CalendarViewType, ThemeType } from '../types';
import { InstallAppButton } from '../components/InstallAppButton';

interface SettingsPageProps {
  onOpenSupabaseModal: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ onOpenSupabaseModal }) => {
  const { settings, updateSettings } = useData();
  const { isSupabaseConfigured, isDemoUser, user } = useAuth();

  const [name, setName] = useState(settings.name);
  const [profilePhoto, setProfilePhoto] = useState(settings.profile_photo || '');
  const [phone, setPhone] = useState(settings.phone || '');
  const [email, setEmail] = useState(settings.email || user?.email || '');
  const [startHour, setStartHour] = useState(settings.start_hour || '08:00');
  const [endHour, setEndHour] = useState(settings.end_hour || '19:00');
  const [firstDayOfWeek, setFirstDayOfWeek] = useState<'sunday' | 'monday'>(settings.first_day_of_week || 'monday');
  const [defaultView, setDefaultView] = useState<CalendarViewType>(settings.default_calendar_view || 'week');
  const [theme, setTheme] = useState<ThemeType>(settings.theme || 'system');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateSettings({
      name,
      profile_photo: profilePhoto || undefined,
      phone: phone || undefined,
      email: email || undefined,
      start_hour: startHour,
      end_hour: endHour,
      first_day_of_week: firstDayOfWeek,
      default_calendar_view: defaultView,
      theme,
    });

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-16">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Settings className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
          <span>Minha Agenda & Configurações</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Personalize seus horários de trabalho, visualização padrão, tema e conexões
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* 1. Dados Pessoais / Profissional */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
            <User className="w-4 h-4 text-indigo-500" />
            <span>Perfil Profissional</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Nome de Exibição
              </label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Ex: Dra. Larissa Souza"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5" /> WhatsApp / Telefone
                </span>
              </label>
              <input
                type="tel"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="(11) 98765-4321"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                <span className="flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5" /> E-mail
                </span>
              </label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="seuemail@exemplo.com"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                URL da Foto de Perfil
              </label>
              <input
                type="url"
                value={profilePhoto}
                onChange={e => setProfilePhoto(e.target.value)}
                placeholder="https://exemplo.com/sua-foto.jpg"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* 2. Horários e Preferências da Agenda */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
            <Clock className="w-4 h-4 text-indigo-500" />
            <span>Horários de Atendimento & Visual</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Horário Inicial
              </label>
              <input
                type="time"
                value={startHour}
                onChange={e => setStartHour(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Horário Final
              </label>
              <input
                type="time"
                value={endHour}
                onChange={e => setEndHour(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                1º Dia da Semana
              </label>
              <select
                value={firstDayOfWeek}
                onChange={e => setFirstDayOfWeek(e.target.value as 'sunday' | 'monday')}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="monday">Segunda-feira</option>
                <option value="sunday">Domingo</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Visual Padrão
              </label>
              <select
                value={defaultView}
                onChange={e => setDefaultView(e.target.value as CalendarViewType)}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="day">Dia</option>
                <option value="week">Semana</option>
                <option value="month">Mês</option>
                <option value="list">Lista</option>
              </select>
            </div>
          </div>
        </div>

        {/* 3. Tema Visual */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
            <Sun className="w-4 h-4 text-indigo-500" />
            <span>Tema da Interface</span>
          </h3>

          <div className="grid grid-cols-3 gap-3">
            {[
              { id: 'light' as ThemeType, label: 'Claro', icon: Sun },
              { id: 'dark' as ThemeType, label: 'Escuro', icon: Moon },
              { id: 'system' as ThemeType, label: 'Sistema', icon: Monitor },
            ].map(t => {
              const Icon = t.icon;
              const isSelected = theme === t.id;
              return (
                <button
                  type="button"
                  key={t.id}
                  onClick={() => setTheme(t.id)}
                  className={`p-4 rounded-xl border flex flex-col items-center justify-center gap-2 transition-all ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 font-bold ring-2 ring-indigo-500 ring-offset-1 dark:ring-offset-slate-900'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-xs">{t.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* 4. Conexão Supabase e RLS */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-emerald-500" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Banco de Dados Supabase (RLS Ativo)
              </h3>
            </div>
            <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
              isSupabaseConfigured
                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
            }`}>
              {isSupabaseConfigured ? 'Conectado à Nuvem' : 'Modo Demo / Local'}
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400">
            Você pode vincular seu próprio projeto Supabase inserindo a URL e a Anon Public Key, além de copiar o script SQL completo com todas as tabelas (appointments, tasks, clients, services, settings) e políticas de segurança.
          </p>

          <button
            type="button"
            onClick={onOpenSupabaseModal}
            className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>Gerenciar Conexão & Script SQL Supabase</span>
          </button>
        </div>

        {/* 5. Instalar Aplicativo */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
            <span>Instalação do Aplicativo (PWA)</span>
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Você e seus usuários podem baixar o AgendaFlow diretamente no smartphone (Android/iOS) ou computador para usar em tela cheia com alta velocidade e sem barra de navegador.
          </p>
          <div className="flex items-center gap-3 flex-wrap">
            <InstallAppButton variant="button" />
            <a
              href="/agendaflow_completo.html"
              download="agendaflow_completo.html"
              className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 flex items-center gap-2 transition-colors"
            >
              <span>📄 Baixar Arquivo .HTML Standalone</span>
            </a>
          </div>
        </div>

        {/* Save Bar */}
        <div className="flex items-center justify-end gap-3 pt-2">
          {savedSuccess && (
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 animate-in fade-in">
              <Check className="w-4 h-4" /> Alterações salvas com sucesso!
            </span>
          )}
          <button
            type="submit"
            className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>Salvar Configurações</span>
          </button>
        </div>
      </form>
    </div>
  );
};
