import React from 'react';
import { 
  Calendar as CalendarIcon, 
  CheckSquare, 
  Clock, 
  MapPin, 
  User, 
  ArrowRight, 
  Plus, 
  MessageSquare, 
  AlertCircle,
  Sparkles,
  CheckCircle2,
  Target
} from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { Appointment, Task } from '../types';
import { 
  COLOR_MAP, 
  formatDateBR, 
  generateWhatsAppMessage, 
  getTodayString, 
  openWhatsApp, 
  PRIORITY_MAP, 
  STATUS_MAP 
} from '../lib/utils';
import { NavTab } from '../components/Sidebar';
import { InstallAppButton } from '../components/InstallAppButton';

interface DashboardPageProps {
  onOpenNewAppointment: () => void;
  onOpenNewTask: () => void;
  onSelectAppointment: (apt: Appointment) => void;
  onSelectTask: (task: Task) => void;
  onNavigateTab: (tab: NavTab) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  onOpenNewAppointment,
  onOpenNewTask,
  onSelectAppointment,
  onSelectTask,
  onNavigateTab,
}) => {
  const { appointments, tasks, toggleTask, settings } = useData();
  const today = getTodayString();

  // Metrics for "Hoje"
  const todayAppointments = appointments.filter(a => a.date === today && a.status !== 'CANCELLED');
  const todayTasks = tasks.filter(t => !t.due_date || t.due_date === today);
  const pendingTasks = todayTasks.filter(t => !t.completed);

  // Next appointment today or upcoming
  const upcomingAppointments = appointments
    .filter(a => a.date >= today && a.status !== 'CANCELLED')
    .sort((a, b) => (a.date + a.start_time).localeCompare(b.date + b.start_time));

  const nextAppointment = upcomingAppointments[0];

  const handleWhatsApp = (e: React.MouseEvent, apt: Appointment) => {
    e.stopPropagation();
    const msg = generateWhatsAppMessage(apt);
    openWhatsApp(apt.client_phone, msg);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Welcome Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-gradient-to-r from-indigo-900 via-indigo-800 to-indigo-950 text-white p-6 rounded-3xl shadow-lg relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center gap-2 text-indigo-200 text-xs font-semibold uppercase tracking-wider mb-1">
            <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
            <span>Visão Geral do Dia</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight">
            Olá, {settings.name ? settings.name.split(' ')[0] : 'Bem-vindo'}! 👋
          </h2>
          <p className="text-sm text-indigo-100/80 mt-1 max-w-md">
            Você tem <span className="font-bold text-white">{todayAppointments.length} compromissos</span> e{' '}
            <span className="font-bold text-white">{pendingTasks.length} tarefas pendentes</span> para hoje.
          </p>
        </div>

        <div className="flex items-center gap-2.5 relative z-10">
          <button
            onClick={onOpenNewAppointment}
            className="px-4 py-2.5 bg-white text-indigo-900 hover:bg-indigo-50 active:bg-indigo-100 rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2"
          >
            <Plus className="w-4 h-4 text-indigo-700" />
            <span>+ Agendar</span>
          </button>
          <button
            onClick={() => onNavigateTab('calendar')}
            className="px-4 py-2.5 bg-indigo-700/50 hover:bg-indigo-700 text-white rounded-xl font-semibold text-xs border border-indigo-400/30 transition-all flex items-center gap-1.5"
          >
            <span>Ver Agenda</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Decorative background glow */}
        <div className="absolute -right-8 -bottom-8 w-48 h-48 bg-indigo-500/20 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Install App Banner for Mobile/PC */}
      <InstallAppButton variant="banner" />

      {/* Leads Capture Quick Action Banner */}
      <div 
        onClick={() => onNavigateTab('leads')}
        className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-indigo-500/10 border border-emerald-500/20 hover:border-emerald-500/40 shadow-xs cursor-pointer transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 group"
      >
        <div className="flex items-center gap-3.5">
          <div className="p-3 rounded-xl bg-emerald-600 text-white shadow-xs group-hover:scale-105 transition-transform">
            <Target className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                Capturar Novos Leads & Clientes
              </h4>
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] font-extrabold uppercase">
                Ativo
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Compartilhe seu link de agendamento, receba contatos do Instagram/WhatsApp e exporte tudo para Excel.
            </p>
          </div>
        </div>

        <button
          type="button"
          className="px-4 py-2 bg-emerald-600 group-hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs whitespace-nowrap transition-colors flex items-center gap-1.5 self-end sm:self-auto"
        >
          <span>Acessar Leads</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Metric Cards ("Hoje") */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
        {/* Total Compromissos */}
        <div 
          onClick={() => onNavigateTab('calendar')}
          className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs hover:border-indigo-300 dark:hover:border-indigo-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Compromissos Hoje</span>
            <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400">
              <CalendarIcon className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            {todayAppointments.length}
          </div>
          <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1 group-hover:text-indigo-600 transition-colors">
            <span>Visualizar na agenda</span>
            <ArrowRight className="w-3 h-3" />
          </p>
        </div>

        {/* Total de Tarefas */}
        <div 
          onClick={() => onNavigateTab('tasks')}
          className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs hover:border-indigo-300 dark:hover:border-indigo-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Tarefas de Hoje</span>
            <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400">
              <CheckSquare className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            {todayTasks.length}
          </div>
          <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1 group-hover:text-indigo-600 transition-colors">
            <span>{todayTasks.filter(t => t.completed).length} concluídas</span>
          </p>
        </div>

        {/* Tarefas Pendentes */}
        <div 
          onClick={() => onNavigateTab('tasks')}
          className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs hover:border-amber-300 dark:hover:border-amber-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Tarefas Pendentes</span>
            <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-amber-600 dark:text-amber-400">
            {pendingTasks.length}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Requerem sua atenção hoje
          </p>
        </div>

        {/* Próximo Compromisso */}
        <div 
          onClick={() => nextAppointment && onSelectAppointment(nextAppointment)}
          className={`p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs transition-all ${
            nextAppointment ? 'hover:border-indigo-300 dark:hover:border-indigo-700 cursor-pointer' : ''
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Próximo Compromisso</span>
            <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          {nextAppointment ? (
            <div>
              <div className="text-base font-bold text-slate-900 dark:text-white truncate">
                {nextAppointment.title}
              </div>
              <div className="flex items-center gap-1.5 text-xs text-indigo-600 dark:text-indigo-400 font-semibold mt-0.5">
                <span>{nextAppointment.date === today ? 'Hoje' : formatDateBR(nextAppointment.date)}</span>
                <span>às</span>
                <span>{nextAppointment.start_time}</span>
              </div>
            </div>
          ) : (
            <div className="text-xs text-slate-400 pt-2 font-medium">
              Nenhum agendamento futuro
            </div>
          )}
        </div>
      </div>

      {/* Main Grid: Próximos Compromissos & Tarefas de Hoje */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Próximos Compromissos */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Próximos Compromissos
              </h3>
            </div>
            <button
              onClick={() => onNavigateTab('calendar')}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
            >
              <span>Ver todos</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {upcomingAppointments.length === 0 ? (
            <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
              <CalendarIcon className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
              <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                Sua agenda está livre!
              </p>
              <p className="text-xs text-slate-400 mt-1">
                Aproveite o tempo livre ou adicione um novo agendamento.
              </p>
              <button
                onClick={onOpenNewAppointment}
                className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition-colors"
              >
                + Novo compromisso
              </button>
            </div>
          ) : (
            <div className="space-y-2.5">
              {upcomingAppointments.slice(0, 6).map(apt => {
                const colorConfig = COLOR_MAP[apt.color];
                const statusConfig = STATUS_MAP[apt.status];
                const isToday = apt.date === today;

                return (
                  <div
                    key={apt.id}
                    onClick={() => onSelectAppointment(apt)}
                    className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-600 shadow-2xs hover:shadow-xs transition-all cursor-pointer group flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3"
                  >
                    {/* Time and Title info */}
                    <div className="flex items-start gap-3.5">
                      <div className={`w-1.5 h-12 rounded-full ${colorConfig.bg} flex-shrink-0`} />
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 transition-colors">
                            {apt.title}
                          </span>
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${statusConfig.badge}`}>
                            {statusConfig.label}
                          </span>
                        </div>

                        <div className="flex items-center flex-wrap gap-x-3 gap-y-1 mt-1 text-xs text-slate-500 dark:text-slate-400">
                          <div className="flex items-center gap-1 font-semibold text-slate-700 dark:text-slate-300">
                            <Clock className="w-3.5 h-3.5 text-indigo-500" />
                            <span>
                              {isToday ? 'Hoje' : formatDateBR(apt.date)}, {apt.start_time} - {apt.end_time}
                            </span>
                          </div>

                          {apt.client_name && (
                            <div className="flex items-center gap-1">
                              <User className="w-3.5 h-3.5 text-slate-400" />
                              <span>{apt.client_name}</span>
                            </div>
                          )}

                          {apt.location && (
                            <div className="flex items-center gap-1">
                              <MapPin className="w-3.5 h-3.5 text-slate-400" />
                              <span className="truncate max-w-[150px]">{apt.location}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-2 self-end sm:self-center">
                      {apt.client_phone && (
                        <button
                          type="button"
                          onClick={(e) => handleWhatsApp(e, apt)}
                          title="Enviar lembrete pelo WhatsApp"
                          className="px-2.5 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300 text-xs font-medium flex items-center gap-1.5 transition-colors border border-emerald-200/60 dark:border-emerald-800"
                        >
                          <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="hidden sm:inline">WhatsApp</span>
                        </button>
                      )}
                      <div className="p-1 text-slate-400 group-hover:text-indigo-600 transition-colors">
                        <ArrowRight className="w-4 h-4" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right 1 Col: Tarefas de Hoje Checklist */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckSquare className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Tarefas de Hoje
              </h3>
            </div>
            <button
              onClick={onOpenNewTask}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Nova</span>
            </button>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 p-4 shadow-2xs space-y-2">
            {todayTasks.length === 0 ? (
              <div className="py-8 text-center text-slate-400">
                <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-500 mb-2 opacity-70" />
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Nenhuma tarefa para hoje!
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Tudo em dia ou adicione novas tarefas.
                </p>
              </div>
            ) : (
              todayTasks.map(task => {
                const priorityConf = PRIORITY_MAP[task.priority];

                return (
                  <div
                    key={task.id}
                    className={`p-3 rounded-xl border transition-all flex items-start gap-3 cursor-pointer group ${
                      task.completed
                        ? 'bg-slate-50 dark:bg-slate-800/30 border-slate-100 dark:border-slate-800/60 opacity-60'
                        : 'bg-white dark:bg-slate-800/70 border-slate-200 dark:border-slate-700/80 hover:border-indigo-400'
                    }`}
                    onClick={() => onSelectTask(task)}
                  >
                    <input
                      type="checkbox"
                      checked={task.completed}
                      onChange={(e) => {
                        e.stopPropagation();
                        toggleTask(task.id);
                      }}
                      className="mt-0.5 w-4 h-4 text-indigo-600 rounded-sm focus:ring-indigo-500 cursor-pointer"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className={`text-xs font-semibold text-slate-900 dark:text-white ${task.completed ? 'line-through text-slate-400' : ''}`}>
                          {task.title}
                        </span>
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${priorityConf.badge}`}>
                          {priorityConf.label}
                        </span>
                      </div>

                      {task.due_time && (
                        <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-1">
                          <Clock className="w-3 h-3" />
                          <span>{task.due_time}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}

            <button
              onClick={() => onNavigateTab('tasks')}
              className="w-full pt-3 pb-1 text-center text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center justify-center gap-1"
            >
              <span>Gerenciar todas as tarefas</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
