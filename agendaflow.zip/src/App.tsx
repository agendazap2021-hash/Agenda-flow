/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';
import { Sidebar, NavTab } from './components/Sidebar';
import { BottomNav } from './components/BottomNav';
import { Header } from './components/Header';
import { DashboardPage } from './pages/DashboardPage';
import { CalendarPage } from './pages/CalendarPage';
import { TasksPage } from './pages/TasksPage';
import { ClientsPage } from './pages/ClientsPage';
import { LeadsCapturePage } from './pages/LeadsCapturePage';
import { ServicesPage } from './pages/ServicesPage';
import { SettingsPage } from './pages/SettingsPage';
import { AuthPage } from './pages/AuthPage';

// Modals
import { AppointmentModal } from './components/AppointmentModal';
import { TaskModal } from './components/TaskModal';
import { ClientModal } from './components/ClientModal';
import { ClientDetailModal } from './components/ClientDetailModal';
import { ServiceModal } from './components/ServiceModal';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { SupabaseModal } from './components/SupabaseModal';

import { Appointment, Client, Service, Task } from './types';

const MainAppContent: React.FC = () => {
  const { user, loading } = useAuth();

  // Navigation tab
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');

  // Modals state
  const [appointmentModalOpen, setAppointmentModalOpen] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [defaultAptDate, setDefaultAptDate] = useState<string | undefined>(undefined);
  const [defaultAptTime, setDefaultAptTime] = useState<string | undefined>(undefined);

  const [taskModalOpen, setTaskModalOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const [clientModalOpen, setClientModalOpen] = useState(false);
  const [selectedClientForEdit, setSelectedClientForEdit] = useState<Client | null>(null);

  const [clientDetailModalOpen, setClientDetailModalOpen] = useState(false);
  const [selectedClientForDetail, setSelectedClientForDetail] = useState<Client | null>(null);

  const [serviceModalOpen, setServiceModalOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<Service | null>(null);

  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [supabaseModalOpen, setSupabaseModalOpen] = useState(false);

  // Global keyboard shortcut for search (Cmd+K / Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchModalOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900 text-white">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-3 border-indigo-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm font-semibold tracking-wide text-slate-300">Carregando AgendaFlow...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthPage onOpenSupabaseModal={() => setSupabaseModalOpen(true)} />;
  }

  // Handlers for creating / editing appointments
  const handleOpenNewAppointment = (date?: string, time?: string) => {
    setSelectedAppointment(null);
    setDefaultAptDate(date);
    setDefaultAptTime(time);
    setAppointmentModalOpen(true);
  };

  const handleSelectAppointment = (apt: Appointment) => {
    setSelectedAppointment(apt);
    setAppointmentModalOpen(true);
  };

  // Handlers for creating / editing tasks
  const handleOpenNewTask = () => {
    setSelectedTask(null);
    setTaskModalOpen(true);
  };

  const handleSelectTask = (task: Task) => {
    setSelectedTask(task);
    setTaskModalOpen(true);
  };

  // Handlers for clients
  const handleOpenNewClient = () => {
    setSelectedClientForEdit(null);
    setClientModalOpen(true);
  };

  const handleEditClient = (client: Client) => {
    setSelectedClientForEdit(client);
    setClientModalOpen(true);
  };

  const handleSelectClientDetail = (client: Client) => {
    setSelectedClientForDetail(client);
    setClientDetailModalOpen(true);
  };

  const handleScheduleForClient = (client: Client) => {
    setSelectedClientForDetail(null);
    setClientDetailModalOpen(false);
    setSelectedAppointment(null);
    setDefaultAptDate(undefined);
    setDefaultAptTime(undefined);
    setAppointmentModalOpen(true);
  };

  // Handlers for services
  const handleOpenNewService = () => {
    setSelectedService(null);
    setServiceModalOpen(true);
  };

  const handleEditService = (service: Service) => {
    setSelectedService(service);
    setServiceModalOpen(true);
  };

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* Desktop Sidebar */}
      <Sidebar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        onOpenNewAppointment={() => handleOpenNewAppointment()}
        onOpenNewTask={handleOpenNewTask}
        onOpenSupabaseModal={() => setSupabaseModalOpen(true)}
      />

      {/* Main Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Sticky Top Header */}
        <Header
          onOpenSearch={() => setSearchModalOpen(true)}
          onOpenNewAppointment={() => handleOpenNewAppointment()}
          onOpenSupabaseModal={() => setSupabaseModalOpen(true)}
        />

        {/* Page Content */}
        <main className="flex-1 p-4 sm:p-6 md:p-8 overflow-y-auto">
          {currentTab === 'dashboard' && (
            <DashboardPage
              onOpenNewAppointment={() => handleOpenNewAppointment()}
              onOpenNewTask={handleOpenNewTask}
              onSelectAppointment={handleSelectAppointment}
              onSelectTask={handleSelectTask}
              onNavigateTab={setCurrentTab}
            />
          )}

          {currentTab === 'calendar' && (
            <CalendarPage
              onOpenNewAppointment={handleOpenNewAppointment}
              onSelectAppointment={handleSelectAppointment}
            />
          )}

          {currentTab === 'tasks' && (
            <TasksPage
              onOpenNewTask={handleOpenNewTask}
              onSelectTask={handleSelectTask}
            />
          )}

          {currentTab === 'clients' && (
            <ClientsPage
              onOpenNewClient={handleOpenNewClient}
              onSelectClient={handleSelectClientDetail}
              onEditClient={handleEditClient}
            />
          )}

          {currentTab === 'leads' && (
            <LeadsCapturePage
              onOpenNewClient={handleOpenNewClient}
              onSelectClient={handleSelectClientDetail}
              onOpenNewAppointment={() => handleOpenNewAppointment()}
            />
          )}

          {currentTab === 'services' && (
            <ServicesPage
              onOpenNewService={handleOpenNewService}
              onEditService={handleEditService}
            />
          )}

          {currentTab === 'settings' && (
            <SettingsPage
              onOpenSupabaseModal={() => setSupabaseModalOpen(true)}
            />
          )}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <BottomNav
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        onOpenNewAppointment={() => handleOpenNewAppointment()}
        onOpenNewTask={handleOpenNewTask}
      />

      {/* All Application Modals */}
      <AppointmentModal
        isOpen={appointmentModalOpen}
        onClose={() => setAppointmentModalOpen(false)}
        initialAppointment={selectedAppointment}
        defaultDate={defaultAptDate}
        defaultTime={defaultAptTime}
      />

      <TaskModal
        isOpen={taskModalOpen}
        onClose={() => setTaskModalOpen(false)}
        initialTask={selectedTask}
      />

      <ClientModal
        isOpen={clientModalOpen}
        onClose={() => setClientModalOpen(false)}
        initialClient={selectedClientForEdit}
      />

      <ClientDetailModal
        isOpen={clientDetailModalOpen}
        onClose={() => setClientDetailModalOpen(false)}
        client={selectedClientForDetail}
        onEdit={(c) => {
          setClientDetailModalOpen(false);
          handleEditClient(c);
        }}
        onScheduleForClient={handleScheduleForClient}
        onSelectAppointment={handleSelectAppointment}
      />

      <ServiceModal
        isOpen={serviceModalOpen}
        onClose={() => setServiceModalOpen(false)}
        initialService={selectedService}
      />

      <GlobalSearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onSelectAppointment={handleSelectAppointment}
        onSelectTask={handleSelectTask}
        onSelectClient={handleSelectClientDetail}
        onSelectService={handleEditService}
      />

      <SupabaseModal
        isOpen={supabaseModalOpen}
        onClose={() => setSupabaseModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <MainAppContent />
      </DataProvider>
    </AuthProvider>
  );
}
