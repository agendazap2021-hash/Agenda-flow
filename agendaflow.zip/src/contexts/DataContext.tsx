import React, { createContext, useContext, useEffect, useState } from 'react';
import { getSupabaseClient } from '../lib/supabase';
import {
  DEFAULT_SETTINGS,
  INITIAL_APPOINTMENTS,
  INITIAL_CLIENTS,
  INITIAL_SERVICES,
  INITIAL_TASKS,
} from '../lib/storage';
import { Appointment, Client, Service, Task, UserSettings } from '../types';
import { useAuth } from './AuthContext';

interface DataContextType {
  appointments: Appointment[];
  tasks: Task[];
  clients: Client[];
  services: Service[];
  settings: UserSettings;
  loading: boolean;
  
  // Appointments
  addAppointment: (apt: Omit<Appointment, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => Promise<Appointment>;
  updateAppointment: (id: string, apt: Partial<Appointment>) => Promise<void>;
  deleteAppointment: (id: string) => Promise<void>;

  // Tasks
  addTask: (task: Omit<Task, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => Promise<Task>;
  updateTask: (id: string, task: Partial<Task>) => Promise<void>;
  toggleTask: (id: string) => Promise<void>;
  deleteTask: (id: string) => Promise<void>;

  // Clients
  addClient: (client: Omit<Client, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => Promise<Client>;
  updateClient: (id: string, client: Partial<Client>) => Promise<void>;
  deleteClient: (id: string) => Promise<void>;

  // Services
  addService: (service: Omit<Service, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => Promise<Service>;
  updateService: (id: string, service: Partial<Service>) => Promise<void>;
  deleteService: (id: string) => Promise<void>;

  // Settings
  updateSettings: (newSettings: Partial<UserSettings>) => Promise<void>;

  // Utilities
  refreshData: () => Promise<void>;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isDemoUser } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [settings, setSettings] = useState<UserSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);

  const storagePrefix = user ? `agendaflow_${user.id}_` : 'agendaflow_default_';

  // Load data when user changes
  useEffect(() => {
    loadAllData();
  }, [user]);

  // Apply theme class to document
  useEffect(() => {
    const root = document.documentElement;
    const theme = settings.theme;

    if (theme === 'dark') {
      root.classList.add('dark');
    } else if (theme === 'light') {
      root.classList.remove('dark');
    } else {
      // System
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      if (mediaQuery.matches) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }

      const handler = (e: MediaQueryListEvent) => {
        if (settings.theme === 'system') {
          if (e.matches) root.classList.add('dark');
          else root.classList.remove('dark');
        }
      };
      mediaQuery.addEventListener('change', handler);
      return () => mediaQuery.removeEventListener('change', handler);
    }
  }, [settings.theme]);

  const loadAllData = async () => {
    setLoading(true);
    const client = getSupabaseClient();

    if (client && user && !isDemoUser) {
      try {
        // Try fetching from Supabase tables
        const [aptRes, taskRes, clientRes, serviceRes, settingsRes] = await Promise.all([
          client.from('appointments').select('*').order('date', { ascending: true }),
          client.from('tasks').select('*').order('created_at', { ascending: false }),
          client.from('clients').select('*').order('name', { ascending: true }),
          client.from('services').select('*').order('name', { ascending: true }),
          client.from('settings').select('*').single(),
        ]);

        if (aptRes.data && aptRes.data.length > 0) {
          setAppointments(aptRes.data);
        } else {
          // Initialize user with demo defaults if new empty account
          setAppointments(INITIAL_APPOINTMENTS.map(a => ({ ...a, user_id: user.id })));
        }

        if (taskRes.data && taskRes.data.length > 0) {
          setTasks(taskRes.data);
        } else {
          setTasks(INITIAL_TASKS.map(t => ({ ...t, user_id: user.id })));
        }

        if (clientRes.data && clientRes.data.length > 0) {
          const globalLeadsRaw = localStorage.getItem('agendaflow_global_captured_leads');
          const globalLeads = globalLeadsRaw ? JSON.parse(globalLeadsRaw) : [];
          const combined = [...globalLeads.map((g: any) => ({ ...g, user_id: user.id })), ...clientRes.data];
          const unique = Array.from(new Map(combined.map(item => [item.name + (item.phone || ''), item])).values());
          setClients(unique);
        } else {
          const globalLeadsRaw = localStorage.getItem('agendaflow_global_captured_leads');
          const globalLeads = globalLeadsRaw ? JSON.parse(globalLeadsRaw) : [];
          setClients([...globalLeads.map((g: any) => ({ ...g, user_id: user.id })), ...INITIAL_CLIENTS.map(c => ({ ...c, user_id: user.id }))]);
        }

        if (serviceRes.data && serviceRes.data.length > 0) {
          setServices(serviceRes.data);
        } else {
          setServices(INITIAL_SERVICES.map(s => ({ ...s, user_id: user.id })));
        }

        if (settingsRes.data) {
          setSettings(settingsRes.data);
        } else {
          setSettings({ ...DEFAULT_SETTINGS, user_id: user.id, email: user.email, name: user.name });
        }

        setLoading(false);
        return;
      } catch (err) {
        console.warn('Could not load from Supabase directly, falling back to local store:', err);
      }
    }

    // Local Storage / Demo Mode fallback
    try {
      const storedApts = localStorage.getItem(`${storagePrefix}appointments`);
      const storedTasks = localStorage.getItem(`${storagePrefix}tasks`);
      const storedClients = localStorage.getItem(`${storagePrefix}clients`);
      const storedServices = localStorage.getItem(`${storagePrefix}services`);
      const storedSettings = localStorage.getItem(`${storagePrefix}settings`);
      const globalLeadsRaw = localStorage.getItem('agendaflow_global_captured_leads');
      const globalLeads = globalLeadsRaw ? JSON.parse(globalLeadsRaw) : [];
      const baseClients = storedClients ? JSON.parse(storedClients) : INITIAL_CLIENTS;
      const combinedLocal = [...globalLeads.map((g: any) => ({ ...g, user_id: user?.id || 'default-user' })), ...baseClients];
      const uniqueLocal = Array.from(new Map(combinedLocal.map(item => [item.name + (item.phone || ''), item])).values());

      setAppointments(storedApts ? JSON.parse(storedApts) : INITIAL_APPOINTMENTS);
      setTasks(storedTasks ? JSON.parse(storedTasks) : INITIAL_TASKS);
      setClients(uniqueLocal);
      setServices(storedServices ? JSON.parse(storedServices) : INITIAL_SERVICES);
      
      if (storedSettings) {
        setSettings(JSON.parse(storedSettings));
      } else if (user) {
        setSettings({ ...DEFAULT_SETTINGS, user_id: user.id, name: user.name, email: user.email });
      } else {
        setSettings(DEFAULT_SETTINGS);
      }
    } catch (e) {
      console.error('Error reading localStorage:', e);
      setAppointments(INITIAL_APPOINTMENTS);
      setTasks(INITIAL_TASKS);
      setClients(INITIAL_CLIENTS);
      setServices(INITIAL_SERVICES);
      setSettings(DEFAULT_SETTINGS);
    } finally {
      setLoading(false);
    }
  };

  // Helper to save to storage
  const saveLocal = (key: string, data: any) => {
    try {
      localStorage.setItem(`${storagePrefix}${key}`, JSON.stringify(data));
    } catch (e) {
      console.error('Local save error', e);
    }
  };

  // Appointments
  const addAppointment = async (
    item: Omit<Appointment, 'id' | 'user_id' | 'created_at' | 'updated_at'>
  ): Promise<Appointment> => {
    const newApt: Appointment = {
      ...item,
      id: 'apt-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      user_id: user?.id || 'default-user',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const updated = [...appointments, newApt];
    setAppointments(updated);
    saveLocal('appointments', updated);

    const client = getSupabaseClient();
    if (client && user && !isDemoUser) {
      try {
        await client.from('appointments').insert([newApt]);
      } catch (err) {
        console.error(err);
      }
    }

    return newApt;
  };

  const updateAppointment = async (id: string, patch: Partial<Appointment>) => {
    const updated = appointments.map(apt => 
      apt.id === id ? { ...apt, ...patch, updated_at: new Date().toISOString() } : apt
    );
    setAppointments(updated);
    saveLocal('appointments', updated);

    const client = getSupabaseClient();
    if (client && user && !isDemoUser) {
      try {
        await client.from('appointments').update({ ...patch, updated_at: new Date().toISOString() }).eq('id', id);
      } catch (err) {
        console.error(err);
      }
    }
  };

  const deleteAppointment = async (id: string) => {
    const updated = appointments.filter(apt => apt.id !== id);
    setAppointments(updated);
    saveLocal('appointments', updated);

    const client = getSupabaseClient();
    if (client && user && !isDemoUser) {
      try {
        await client.from('appointments').delete().eq('id', id);
      } catch (err) {
        console.error(err);
      }
    }
  };

  // Tasks
  const addTask = async (
    item: Omit<Task, 'id' | 'user_id' | 'created_at' | 'updated_at'>
  ): Promise<Task> => {
    const newTask: Task = {
      ...item,
      id: 'tsk-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      user_id: user?.id || 'default-user',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const updated = [newTask, ...tasks];
    setTasks(updated);
    saveLocal('tasks', updated);

    const client = getSupabaseClient();
    if (client && user && !isDemoUser) {
      try {
        await client.from('tasks').insert([newTask]);
      } catch (err) {
        console.error(err);
      }
    }

    return newTask;
  };

  const updateTask = async (id: string, patch: Partial<Task>) => {
    const updated = tasks.map(t =>
      t.id === id ? { ...t, ...patch, updated_at: new Date().toISOString() } : t
    );
    setTasks(updated);
    saveLocal('tasks', updated);

    const client = getSupabaseClient();
    if (client && user && !isDemoUser) {
      try {
        await client.from('tasks').update({ ...patch, updated_at: new Date().toISOString() }).eq('id', id);
      } catch (err) {
        console.error(err);
      }
    }
  };

  const toggleTask = async (id: string) => {
    const task = tasks.find(t => t.id === id);
    if (!task) return;
    await updateTask(id, { completed: !task.completed });
  };

  const deleteTask = async (id: string) => {
    const updated = tasks.filter(t => t.id !== id);
    setTasks(updated);
    saveLocal('tasks', updated);

    const client = getSupabaseClient();
    if (client && user && !isDemoUser) {
      try {
        await client.from('tasks').delete().eq('id', id);
      } catch (err) {
        console.error(err);
      }
    }
  };

  // Clients
  const addClient = async (
    item: Omit<Client, 'id' | 'user_id' | 'created_at' | 'updated_at'>
  ): Promise<Client> => {
    const newClient: Client = {
      ...item,
      id: 'cli-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      user_id: user?.id || 'default-user',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const updated = [...clients, newClient];
    setClients(updated);
    saveLocal('clients', updated);

    const client = getSupabaseClient();
    if (client && user && !isDemoUser) {
      try {
        await client.from('clients').insert([newClient]);
      } catch (err) {
        console.error(err);
      }
    }

    return newClient;
  };

  const updateClient = async (id: string, patch: Partial<Client>) => {
    const updated = clients.map(c =>
      c.id === id ? { ...c, ...patch, updated_at: new Date().toISOString() } : c
    );
    setClients(updated);
    saveLocal('clients', updated);

    const client = getSupabaseClient();
    if (client && user && !isDemoUser) {
      try {
        await client.from('clients').update({ ...patch, updated_at: new Date().toISOString() }).eq('id', id);
      } catch (err) {
        console.error(err);
      }
    }
  };

  const deleteClient = async (id: string) => {
    const updated = clients.filter(c => c.id !== id);
    setClients(updated);
    saveLocal('clients', updated);

    const client = getSupabaseClient();
    if (client && user && !isDemoUser) {
      try {
        await client.from('clients').delete().eq('id', id);
      } catch (err) {
        console.error(err);
      }
    }
  };

  // Services
  const addService = async (
    item: Omit<Service, 'id' | 'user_id' | 'created_at' | 'updated_at'>
  ): Promise<Service> => {
    const newService: Service = {
      ...item,
      id: 'srv-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      user_id: user?.id || 'default-user',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const updated = [...services, newService];
    setServices(updated);
    saveLocal('services', updated);

    const client = getSupabaseClient();
    if (client && user && !isDemoUser) {
      try {
        await client.from('services').insert([newService]);
      } catch (err) {
        console.error(err);
      }
    }

    return newService;
  };

  const updateService = async (id: string, patch: Partial<Service>) => {
    const updated = services.map(s =>
      s.id === id ? { ...s, ...patch, updated_at: new Date().toISOString() } : s
    );
    setServices(updated);
    saveLocal('services', updated);

    const client = getSupabaseClient();
    if (client && user && !isDemoUser) {
      try {
        await client.from('services').update({ ...patch, updated_at: new Date().toISOString() }).eq('id', id);
      } catch (err) {
        console.error(err);
      }
    }
  };

  const deleteService = async (id: string) => {
    const updated = services.filter(s => s.id !== id);
    setServices(updated);
    saveLocal('services', updated);

    const client = getSupabaseClient();
    if (client && user && !isDemoUser) {
      try {
        await client.from('services').delete().eq('id', id);
      } catch (err) {
        console.error(err);
      }
    }
  };

  // Settings
  const updateSettings = async (patch: Partial<UserSettings>) => {
    const updated: UserSettings = {
      ...settings,
      ...patch,
      updated_at: new Date().toISOString(),
    };
    setSettings(updated);
    saveLocal('settings', updated);

    const client = getSupabaseClient();
    if (client && user && !isDemoUser) {
      try {
        await client.from('settings').upsert({ ...updated, user_id: user.id });
      } catch (err) {
        console.error(err);
      }
    }
  };

  return (
    <DataContext.Provider
      value={{
        appointments,
        tasks,
        clients,
        services,
        settings,
        loading,
        addAppointment,
        updateAppointment,
        deleteAppointment,
        addTask,
        updateTask,
        toggleTask,
        deleteTask,
        addClient,
        updateClient,
        deleteClient,
        addService,
        updateService,
        deleteService,
        updateSettings,
        refreshData: loadAllData,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
