import React, { createContext, useContext, useEffect, useState } from 'react';
import { getSupabaseClient, getSupabaseCredentials, resetSupabaseClient, saveSupabaseCredentials } from '../lib/supabase';
import { UserProfile } from '../types';

interface AuthContextType {
  user: UserProfile | null;
  loading: boolean;
  isDemoUser: boolean;
  isSupabaseConfigured: boolean;
  signIn: (email: string, password: string) => Promise<{ error?: string }>;
  signUp: (email: string, password: string, name: string) => Promise<{ error?: string; message?: string }>;
  registerPublicLead: (lead: { name: string; phone?: string; email?: string; notes?: string }) => Promise<{ success: boolean; error?: string }>;
  resetPassword: (email: string) => Promise<{ error?: string; message?: string }>;
  signOut: () => Promise<void>;
  loginAsDemo: () => void;
  updateSupabaseConfig: (url: string, key: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DEMO_USER: UserProfile = {
  id: 'admin-master',
  email: 'netcellinfo@gmail.com',
  name: 'Administrador (Éder)',
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isDemoUser, setIsDemoUser] = useState(false);

  const supabase = getSupabaseClient();
  const credentials = getSupabaseCredentials();
  const isSupabaseConfigured = Boolean(credentials.url && credentials.anonKey);

  useEffect(() => {
    let isMounted = true;

    async function initAuth() {
      // Check if user was previously in demo mode
      const savedDemo = localStorage.getItem('agendaflow_demo_active');

      if (supabase) {
        try {
          const { data: { session } } = await supabase.auth.getSession();
          if (session?.user && isMounted) {
            setUser({
              id: session.user.id,
              email: session.user.email || '',
              name: session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'Usuário',
            });
            setIsDemoUser(false);
            setLoading(false);
            return;
          }
        } catch (err) {
          console.error('Error fetching Supabase session:', err);
        }
      }

      if (savedDemo === 'true' || !isSupabaseConfigured) {
        // Default to demo/quick-start mode so the app works out of the box
        if (isMounted) {
          setUser(DEMO_USER);
          setIsDemoUser(true);
          setLoading(false);
        }
      } else {
        if (isMounted) {
          setUser(null);
          setIsDemoUser(false);
          setLoading(false);
        }
      }
    }

    initAuth();

    // Listen for auth state changes if Supabase is active
    let authListener: { subscription: { unsubscribe: () => void } } | null = null;
    if (supabase) {
      const { data } = supabase.auth.onAuthStateChange((_event, session) => {
        if (session?.user) {
          setUser({
            id: session.user.id,
            email: session.user.email || '',
            name: session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'Usuário',
          });
          setIsDemoUser(false);
          localStorage.removeItem('agendaflow_demo_active');
        } else if (!isDemoUser) {
          setUser(null);
        }
        setLoading(false);
      });
      authListener = data;
    }

    return () => {
      isMounted = false;
      authListener?.subscription.unsubscribe();
    };
  }, [supabase, isSupabaseConfigured, isDemoUser]);

  const signIn = async (email: string, password: string): Promise<{ error?: string }> => {
    // Verificação de Administrador Mestre Master Credentials
    if (email.trim().toLowerCase() === 'netcellinfo@gmail.com' && (password === 'Eder2021@#' || password === 'eder2021@#')) {
      const adminProfile = {
        id: 'admin-master',
        email: 'netcellinfo@gmail.com',
        name: 'Éder (Administrador)',
      };
      setUser(adminProfile);
      setIsDemoUser(false);
      localStorage.setItem('agendaflow_demo_active', 'true');
      return {};
    }

    const client = getSupabaseClient();
    if (!client) {
      // If no Supabase configured, fallback to demo user check
      if (email && password) {
        setUser({
          id: 'user-' + btoa(email).slice(0, 8),
          email: email,
          name: email.split('@')[0],
        });
        setIsDemoUser(false);
        localStorage.setItem('agendaflow_demo_active', 'true');
        return {};
      }
      return { error: 'Supabase não configurado. Use o Modo Demonstração ou adicione as chaves em Configurações.' };
    }

    try {
      const { data, error } = await client.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        return { error: error.message };
      }

      if (data.user) {
        setUser({
          id: data.user.id,
          email: data.user.email || '',
          name: data.user.user_metadata?.name || data.user.email?.split('@')[0] || 'Usuário',
        });
        setIsDemoUser(false);
        localStorage.removeItem('agendaflow_demo_active');
      }

      return {};
    } catch (err: any) {
      return { error: err?.message || 'Erro ao realizar login.' };
    }
  };

  const signUp = async (email: string, password: string, name: string): Promise<{ error?: string; message?: string }> => {
    const client = getSupabaseClient();
    if (!client) {
      setUser({
        id: 'user-' + Date.now(),
        email: email,
        name: name || email.split('@')[0],
      });
      setIsDemoUser(false);
      return { message: 'Conta criada em modo local com sucesso!' };
    }

    try {
      const { data, error } = await client.auth.signUp({
        email,
        password,
        options: {
          data: { name },
        },
      });

      if (error) {
        return { error: error.message };
      }

      if (data.user && data.session) {
        setUser({
          id: data.user.id,
          email: data.user.email || '',
          name: name,
        });
        setIsDemoUser(false);
        return { message: 'Conta criada com sucesso!' };
      }

      return { message: 'Conta criada! Verifique seu e-mail para confirmar o cadastro no Supabase.' };
    } catch (err: any) {
      return { error: err?.message || 'Erro ao criar conta.' };
    }
  };

  const registerPublicLead = async (lead: { name: string; phone?: string; email?: string; notes?: string }): Promise<{ success: boolean; error?: string }> => {
    try {
      const client = getSupabaseClient();
      const leadEntry = {
        id: 'lead-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
        name: lead.name,
        phone: lead.phone || null,
        email: lead.email || null,
        notes: lead.notes || 'Lead capturado na tela de entrada',
        created_at: new Date().toISOString(),
      };

      // 1. Sempre salvar em lista global de leads no localStorage
      try {
        const storedGlobalLeads = localStorage.getItem('agendaflow_global_captured_leads');
        const list = storedGlobalLeads ? JSON.parse(storedGlobalLeads) : [];
        list.unshift(leadEntry);
        localStorage.setItem('agendaflow_global_captured_leads', JSON.stringify(list));

        // Também salvar na base local do usuário default/demo para aparecer no painel imediatamente
        const defaultClients = localStorage.getItem('agendaflow_default-user_clients');
        const defaultList = defaultClients ? JSON.parse(defaultClients) : [];
        defaultList.unshift({
          ...leadEntry,
          user_id: 'default-user',
          updated_at: new Date().toISOString()
        });
        localStorage.setItem('agendaflow_default-user_clients', JSON.stringify(defaultList));
      } catch (e) {
        console.error('Erro salvando lead localmente:', e);
      }

      // 2. Se o Supabase estiver disponível, tentar gravar na tabela clients (se anônimo permitido) ou salvar com sucesso
      if (client) {
        try {
          await client.from('clients').insert([{
            name: lead.name,
            phone: lead.phone || null,
            email: lead.email || null,
            notes: lead.notes || 'Lead capturado na tela de entrada',
          }]);
        } catch {
          // RLS pode exigir autenticação, fallback local garantido acima
        }
      }

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Erro ao registrar solicitação.' };
    }
  };

  const resetPassword = async (email: string): Promise<{ error?: string; message?: string }> => {
    const client = getSupabaseClient();
    if (!client) {
      return { message: 'Instruções de redefinição simuladas enviadas para o e-mail!' };
    }

    try {
      const { error } = await client.auth.resetPasswordForEmail(email);
      if (error) {
        return { error: error.message };
      }
      return { message: 'E-mail de recuperação enviado com sucesso!' };
    } catch (err: any) {
      return { error: err?.message || 'Erro ao solicitar recuperação de senha.' };
    }
  };

  const signOut = async () => {
    const client = getSupabaseClient();
    if (client) {
      try {
        await client.auth.signOut();
      } catch (err) {
        console.error('Error signing out of Supabase:', err);
      }
    }
    localStorage.removeItem('agendaflow_demo_active');
    setUser(null);
    setIsDemoUser(false);
  };

  const loginAsDemo = () => {
    setUser(DEMO_USER);
    setIsDemoUser(true);
    localStorage.setItem('agendaflow_demo_active', 'true');
  };

  const updateSupabaseConfig = async (url: string, key: string): Promise<boolean> => {
    saveSupabaseCredentials(url, key);
    resetSupabaseClient();
    // Test client
    const client = getSupabaseClient();
    if (client) {
      try {
        await client.auth.getSession();
        return true;
      } catch {
        return true;
      }
    }
    return false;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isDemoUser,
        isSupabaseConfigured,
        signIn,
        signUp,
        registerPublicLead,
        resetPassword,
        signOut,
        loginAsDemo,
        updateSupabaseConfig,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
